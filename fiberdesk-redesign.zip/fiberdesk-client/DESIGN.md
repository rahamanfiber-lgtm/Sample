---
name: FiberDesk
description: A precise, compact workspace for local recharge operations.
colors:
  primary: "#175CD3"
  canvas: "#F8FAFC"
  surface: "#FFFFFF"
  ink: "#101828"
  muted: "#667085"
  secondary-ink: "#475467"
  control-ink: "#344054"
  border: "#E4E7EC"
  control-border: "#D0D5DD"
  neutral-hover: "#F2F4F7"
  focus: "#84ADFF"
  expired: "#B42318"
  expired-surface: "#FEF3F2"
  warning: "#93370D"
  warning-surface: "#FFFAEB"
  active: "#067647"
  active-surface: "#ECFDF3"
  blue-surface: "#EFF4FF"
  destructive: "#D92D20"
typography:
  headline:
    fontFamily: '"Inter Variable", sans-serif'
    fontSize: "28px"
    fontWeight: 650
    lineHeight: 1.3
    letterSpacing: "-0.8px"
  title:
    fontFamily: '"Inter Variable", sans-serif'
    fontSize: "17px"
    fontWeight: 630
    letterSpacing: "-0.3px"
  body:
    fontFamily: '"Inter Variable", sans-serif'
    fontSize: "14px"
    lineHeight: 1.5
  label:
    fontFamily: '"Inter Variable", sans-serif'
    fontSize: "12px"
  counter:
    fontFamily: '"Inter Variable", sans-serif'
    fontSize: "30px"
    fontWeight: 620
    lineHeight: 1.5
    letterSpacing: "-1px"
rounded:
  tag: "5px"
  control: "8px"
  panel: "12px"
  dialog: "16px"
spacing:
  xs: "4px"
  sm: "8px"
  md: "12px"
  lg: "16px"
  xl: "24px"
  xxl: "32px"
  page: "40px"
components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.surface}"
    rounded: "{rounded.control}"
    padding: "9px 14px"
  button-primary-hover:
    backgroundColor: "{colors.ink}"
    textColor: "{colors.surface}"
  button-outline:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.control-ink}"
    rounded: "{rounded.control}"
    padding: "9px 14px"
  button-ghost:
    backgroundColor: "transparent"
    textColor: "{colors.secondary-ink}"
    rounded: "{rounded.control}"
    padding: "9px 14px"
  button-destructive:
    backgroundColor: "{colors.destructive}"
    textColor: "{colors.surface}"
    rounded: "{rounded.control}"
    padding: "9px 14px"
  field:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "9px 11px"
  panel:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.panel}"
  badge-expired:
    backgroundColor: "{colors.expired-surface}"
    textColor: "{colors.expired}"
    rounded: "{rounded.tag}"
    padding: "3px 7px"
---

# Design System: FiberDesk

## Overview

FiberDesk is an Operate-mode workspace: quiet, compact, and precise. White panels on an offwhite ground prioritize expiry counts, manual reminders, and customer records. The supplied brief establishes the aesthetic; the implemented stylesheet and components establish the values below.

Key characteristics: blue actions, semantic urgency colors, tabular numbers, clear outlines, and restrained feedback motion. Manual reminder tracking remains an operator action.

## Colors

Primary blue identifies actions and selected navigation. Ink and muted neutrals carry the information hierarchy. Red marks expired records, amber approaching expiry, and green active plans; each status includes a text label. Status backgrounds are pale supporting surfaces, not decorative accents. Customer initials use deterministic HSL avatar colors, generated from record identity rather than a fixed brand palette.

## Typography

Self-hosted Inter Variable is the sole family. Global text uses `cv11`, `ss01`, and tabular numerals. Desktop headings are 28px; section titles 17px; counters 30px; body and standard controls 14px. Metadata and status labels generally use 12px. Desktop table body is 13px above 1200px. At mobile, page headings become 24px, counters 28px, and form controls 16px to preserve readability and avoid input zoom. Do not restore superseded 10–11px task-critical metadata from earlier stylesheet declarations.

## Layout

Mobile-first at every screen width, per the latest user instruction. Header and main share a centered 520px maximum width with 16px content gutters. Summary counters use two columns. Customer records always use stacked cards; the desktop table is hidden. Reminders remain a horizontal compact queue. Search, connection filter and expiry sorting stack above status tabs. Controls use at least 44px height. Dialogs are bottom sheets at every width, capped at 520px; form controls are 16px with 48px height. Activation date and validity remain side by side. Respect reduced motion and safe areas.

## Elevation & Depth

Panels rely on white surfaces and 1px borders rather than resting shadows. Primary buttons use `0 1px 2px #1018280a`; outline controls use `0 1px 2px #10182805`. Dropdowns use `0 8px 24px #1018281a`, dialogs `0 24px 70px #10182826`, and selected counters a subtle `0 0 0 1px #eff4ff` ring. The dialog backdrop is `#10182870`.

## Shapes

Panels use 12px corners; dialogs 16px; controls 8px. Small status chips use 5px, demo tags 4px, and avatars circles. Preserve the requested 12–16px panel language. Use neutral borders for grouping and clipping at table-panel edges.

## Components

Buttons expose primary, outline, ghost, and destructive variants, plus small and icon sizes. Standard buttons have a 40px minimum height, 9px 14px padding, 8px gaps, and weight 550. Primary hover becomes ink; outline hover becomes canvas; ghost hover becomes neutral gray. Destructive hover becomes expired red. Disabled buttons use 0.45 opacity.

Fields have a white background, 1px control border, 8px corners, and 40px minimum height; mobile fields reach 44px. Invalid fields receive a red border and an inline error. Interactive controls share a 3px blue focus outline with a 3px offset.

Status chips combine a colored dot with a text label. Demo records retain their visible Demo tag. Counters are interactive filters: hover strengthens the border, selected state adds a pale blue border and ring. Reminder cards present identity, expiry, and direct manual checklist/renewal actions.

Navigation has two destinations, muted resting labels, blue hover, and a 3px blue underline for the current view. Customer action menus use Radix primitives with visible highlighted rows. Dialogs provide separated header, body, and footer regions; mobile footers remain sticky with safe-area padding.

Transitions last 160ms for background, color, border, and shadow. Dialogs fade in over 160ms with ease-out. Reduced motion disables animation and transitions.

## Do's and Don'ts

- Do preserve blue #175CD3, offwhite #F8FAFC, Inter, and compact outlined panels.
- Do place actionable expiry information before the customer list and preserve semantic text labels.
- Do retain keyboard focus, mobile card actions, and manual reminders.
- Don't introduce decorative analytics, fake growth metrics, or unnecessary sidebar destinations.
- Don't send messages automatically; WhatsApp opens only for real valid numbers, with demo preview-only safeguards.
- Don't hide the fictional nature of seeded Demo records.

Simplified customer entry keeps name, number, alternate number, plan, activation date and validity upfront. Expiry and days remaining are derived automatically. Connection type, area, amount and notes live under More details. WhatsApp is beside the phone and available in row actions.

Cloud access uses a phone-first sign-in screen with a prefilled operator email, a username/password form (username test) with a Sign in button, plus an email sign-in link fallback. Loading, unauthorized, sent-email and network-error states preserve the visual system. Signed-in workspace uses Refresh customers and Sign out controls. Confirm saves only after the database succeeds; retain forms on errors.
