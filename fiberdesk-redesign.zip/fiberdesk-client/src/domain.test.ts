import { describe, it, expect } from "vitest";
import {
  todayIST,
  addDays,
  addCalendarMonths,
  validityLabel,
  daysLeft,
  seedCustomers,
  matches,
  csv,
  validDate,
  isCustomer,
  whatsappUrl,
  reminderMessage,
} from "./domain";
describe("Asia/Kolkata calendar arithmetic", () => {
  it("changes date at IST midnight, independently of browser timezone", () => {
    expect(todayIST(new Date("2026-11-19T18:29:59Z"))).toBe("2026-11-19");
    expect(todayIST(new Date("2026-11-19T18:30:00Z"))).toBe("2026-11-20");
  });
  it("handles year boundaries and leap days", () => {
    expect(addDays("2026-12-31", 1)).toBe("2027-01-01");
    expect(addDays("2028-02-28", 1)).toBe("2028-02-29");
    expect(daysLeft("2027-01-01", "2026-12-31")).toBe(1);
    expect(validDate("2026-02-30")).toBe(false);
  });
  it("seeds exactly the requested ten records with reconciled counters", () => {
    const today = "2026-11-20",
      data = seedCustomers(today);
    expect(data).toHaveLength(10);
    expect(data.map((c) => daysLeft(c.expiryDate, today))).toEqual([
      -5, -1, 0, 1, 2, 5, 7, 12, 20, 30,
    ]);
    expect(data.filter((c) => matches(c, "Expired", today))).toHaveLength(2);
    expect(data.filter((c) => matches(c, "Today", today))).toHaveLength(1);
    expect(data.filter((c) => matches(c, "Next 2 Days", today))).toHaveLength(
      2,
    );
    expect(data.filter((c) => matches(c, "Active", today))).toHaveLength(5);
    expect(new Set(data.map((c) => c.mobile)).size).toBe(10);
    for (const c of data)
      expect(addDays(c.rechargeDate, c.validity)).toBe(c.expiryDate);
  });
  it("advances status when the calendar changes", () => {
    const c = seedCustomers("2026-11-20")[3];
    expect(matches(c, "Next 2 Days", "2026-11-20")).toBe(true);
    expect(matches(c, "Today", "2026-11-21")).toBe(true);
    expect(matches(c, "Expired", "2026-11-22")).toBe(true);
  });
});
describe("CSV export", () => {
  it("escapes quotes, newlines, and spreadsheet formulas", () => {
    const c = seedCustomers("2026-11-20")[0];
    c.name = "=1+1";
    c.notes = 'Line 1, "hello"\nLine 2';
    const text = csv([c]);
    expect(text).toContain('"\'=1+1"');
    expect(text).toContain('"Line 1, ""hello""\nLine 2"');
    expect(text).toContain(c.mobile);
  });
});

describe("stored history validation", () => {
  it("rejects malformed history before activity rendering", () => {
    const c = seedCustomers("2026-11-20")[0];
    expect(isCustomer(c)).toBe(true);
    expect(isCustomer({ ...c, renewals: [{}] })).toBe(false);
    expect(isCustomer({ ...c, reminders: [null] })).toBe(false);
    expect(
      isCustomer({
        ...c,
        renewals: [
          {
            rechargeDate: "2026-11-20",
            validity: 30,
            plan: "Plan",
            amount: 599,
            recordedAt: "2026-11-20T08:00:00Z",
          },
        ],
      }),
    ).toBe(true);
  });
});

describe("manual WhatsApp links", () => {
  it("blocks every demo and invalid number while encoding a real contact reminder", () => {
    const c = seedCustomers("2026-11-20")[0];
    expect(whatsappUrl(c, "2026-11-20")).toBeNull();
    const contact = { ...c, demo: false, mobile: "9876543210" };
    const url = whatsappUrl(contact, "2026-11-20");
    expect(url).toContain("https://wa.me/919876543210?text=");
    expect(decodeURIComponent(url!.split("?text=")[1])).toBe(
      reminderMessage(contact, "2026-11-20"),
    );
    expect(whatsappUrl({ ...contact, mobile: "0000000000" })).toBeNull();
  });
});

describe("calendar-month plans", () => {
  it("uses calendar months and clamps month ends", () => {
    expect(addCalendarMonths("2026-01-31", 1)).toBe("2026-02-28");
    expect(addCalendarMonths("2028-01-31", 1)).toBe("2028-02-29");
    expect(addCalendarMonths("2028-02-29", 12)).toBe("2029-02-28");
    for (const n of [1, 2, 4, 6, 8, 12]) {
      const expiry = addCalendarMonths("2026-11-20", n);
      expect(addDays("2026-11-20", daysLeft(expiry, "2026-11-20"))).toBe(
        expiry,
      );
    }
    expect(validityLabel({ validity: 31, validityMonths: 1 })).toBe("1 month");
  });
});

 describe("customer coordinates", () => {
  it("accepts optional coordinates and rejects out-of-range coordinates", () => {
    const c = seedCustomers("2026-11-20")[0];
    expect(isCustomer({...c, latitude: 22.5726, longitude: 88.3639})).toBe(true);
    expect(isCustomer({...c, latitude: 91})).toBe(false);
    expect(isCustomer({...c, longitude: -181})).toBe(false);
    expect(isCustomer({...c, latitude: NaN})).toBe(false);
  });
});
