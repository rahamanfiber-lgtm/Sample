import {describe,it,expect} from 'vitest';
import {parseCoordinates,coordinatesText,googleMapsUrl} from './location';
import {previewBulk} from './bulk';
describe('customer coordinates and maps',()=>{
 it('reads the requested comma-separated field and allows zero and negative coordinates',()=>{expect(parseCoordinates('22.736390,88.373882')).toEqual({latitude:22.73639,longitude:88.373882});expect(parseCoordinates(' 0, -180 ')).toEqual({latitude:0,longitude:-180});expect(parseCoordinates('')).toBeUndefined();});
 it('rejects partial, nonnumeric and out-of-range coordinates',()=>{for(const value of ['22,','22','22,88,1','NaN,88','91,88','22,-181','22x,88','Infinity,0'])expect(()=>parseCoordinates(value)).toThrow();});
 it('preserves legacy coordinates and creates an exact encoded Google Maps search',()=>{expect(coordinatesText({latitude:22.73639,longitude:88.373882})).toBe('22.73639,88.373882');const url=new URL(googleMapsUrl({latitude:22.73639,longitude:88.373882})!);expect(url.origin).toBe('https://www.google.com');expect(url.searchParams.get('query')).toBe('22.73639,88.373882');expect(url.searchParams.get('api')).toBe('1');expect(googleMapsUrl({latitude:22})).toBeNull();expect(googleMapsUrl({latitude:NaN,longitude:88})).toBeNull();});
 it('opens a location name when coordinates are missing and prefers exact coordinates when present',()=>{
  expect(new URL(googleMapsUrl({location:'Gobardanga'})!).searchParams.get('query')).toBe('Gobardanga');
  expect(new URL(googleMapsUrl({location:'Gobardanga',latitude:22.73639,longitude:88.373882})!).searchParams.get('query')).toBe('22.73639,88.373882');
  expect(googleMapsUrl({location:'  '})).toBeNull();
 });
 it('imports the single field from Excel/CSV while retaining legacy column support',()=>{const rows=previewBulk('Name,Number,Coordinates\nA,9876543210,"22.736390,88.373882"',[]);expect(rows[0].errors).toEqual([]);expect(rows[0].customer.longitude).toBe(88.373882);expect(previewBulk('Name,Number,Coordinates\nA,9876543210,"22,"',[])[0].errors.length).toBeGreaterThan(0);});
});
