import { describe, it, expect, vi, beforeEach } from "vitest";
const { rpc } = vi.hoisted(() => ({ rpc: vi.fn() }));
vi.mock("@supabase/supabase-js", () => ({ createClient: () => ({ rpc }) }));
import {
  loadWorkspace,
  saveWorkspace,
  resolveLoginEmail,
  validateSnapshot,
} from "./supabase";
import { seedCustomers } from "../domain";
beforeEach(() => rpc.mockReset());
describe("cloud data boundary", () => {
  it("rejects malformed cloud snapshots before rendering", () => {
    expect(() =>
      validateSnapshot({ revision: 1, initialized: true, customers: [{}] }),
    ).toThrow();
    expect(() =>
      validateSnapshot({ revision: -1, initialized: true, customers: [] }),
    ).toThrow();
  });
  it("loads initialized empty workspaces without demo reseeding", async () => {
    rpc.mockReturnValue({ abortSignal: vi.fn().mockResolvedValue({
      data: { revision: 3, initialized: true, customers: [] },
      error: null,
    }) });
    expect(await loadWorkspace()).toEqual({
      revision: 3,
      initialized: true,
      customers: [],
    });
  });
  it("sends an expected revision with every atomic save", async () => {
    const customers = seedCustomers("2026-11-20");
    rpc.mockResolvedValue({ data: 8, error: null });
    expect(await saveWorkspace(7, customers)).toBe(8);
    expect(rpc).toHaveBeenCalledWith("fiberdesk_save_workspace", {
      expected_revision: 7,
      customers,
    });
  });
  it("turns a stale revision into a refresh instruction", async () => {
    rpc.mockResolvedValue({ error: { code: "40001", message: "conflict" } });
    await expect(saveWorkspace(0, [])).rejects.toThrow("Another device");
  });
  it("does not send invalid local data to the database", async () => {
    await expect(saveWorkspace(0, [{} as never])).rejects.toThrow("invalid");
    expect(rpc).not.toHaveBeenCalled();
  });
});

describe("operator login alias", () => {
  it("maps only the test username and operator email", () => {
    expect(resolveLoginEmail(" TEST ")).toBe("rahaman.fiber@gmail.com");
    expect(resolveLoginEmail("rahaman.fiber@gmail.com")).toBe(
      "rahaman.fiber@gmail.com",
    );
    expect(resolveLoginEmail("someone@example.invalid")).toBeNull();
  });
});
