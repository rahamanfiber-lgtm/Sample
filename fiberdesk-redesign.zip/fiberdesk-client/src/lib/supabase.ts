import { createClient } from "@supabase/supabase-js";
import { isCustomer, type Customer } from "../domain";
export const OPERATOR_EMAIL = (import.meta.env.VITE_OPERATOR_EMAIL || "").trim().toLowerCase();
const projectUrl = import.meta.env.VITE_SUPABASE_URL;
const publishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
if (!projectUrl || !publishableKey || !OPERATOR_EMAIL) throw new Error("Client deployment settings are incomplete.");
export function resolveLoginEmail(identity: string) {
  const value = identity.trim().toLowerCase();
  return value === "test" || value === OPERATOR_EMAIL ? OPERATOR_EMAIL : null;
}
// Publishable key is designed for browser use. RLS and verified operator identity protect every row.
export const supabase = createClient(
  projectUrl,
  publishableKey,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
  },
);
export interface CloudSnapshot {
  customers: Customer[];
  revision: number;
  initialized: boolean;
}
export function validateSnapshot(data: unknown): CloudSnapshot {
  const d = data as CloudSnapshot;
  if (
    !d ||
    !Number.isSafeInteger(d.revision) ||
    d.revision < 0 ||
    typeof d.initialized !== "boolean" ||
    !Array.isArray(d.customers) ||
    !d.customers.every(isCustomer)
  )
    throw new Error(
      "The saved customer data could not be read. Your database has not been changed.",
    );
  return d;
}
export async function loadWorkspace(): Promise<CloudSnapshot> {
  const { data, error } = await supabase.rpc("fiberdesk_load_workspace").abortSignal(AbortSignal.timeout(15000));
  if (error) throw new Error(error.message);
  return validateSnapshot(data);
}
export async function saveWorkspace(
  revision: number,
  customers: Customer[],
): Promise<number> {
  if (!customers.every(isCustomer))
    throw new Error("Some customer details are invalid. Nothing was saved.");
  const { data, error } = await supabase.rpc("fiberdesk_save_workspace", {
    expected_revision: revision,
    customers,
  });
  if (error) {
    if (error.code === "40001")
      throw new Error(
        "Another device updated these customers. Close this form and refresh the list before trying again.",
      );
    if (error.code === "23505")
      throw new Error(
        "That mobile number already belongs to another customer.",
      );
    throw new Error(
      "Save not confirmed. Check your connection, then refresh customers before trying again.",
    );
  }
  if (!Number.isSafeInteger(data))
    throw new Error(
      "Could not confirm the save. Refresh the list before trying again.",
    );
  return data;
}
