import { useEffect, useMemo, useState, useRef } from "react";
import {
  Wifi,
  Plus,
  Search,
  Download,
  Users,
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  ArrowUpDown,
  RefreshCw,
  Check,
  Clock3,
  Info,
  ShieldCheck,
  SlidersHorizontal,
  Bell,
  LayoutDashboard,
  TriangleAlert,
  Inbox,
  Router,
  MessageCircle,
  ExternalLink,
  CloudUpload,
} from "lucide-react";
import { toast, Toaster } from "sonner";
import {
  addDays,
  csv,
  readCustomers,
  STORAGE_KEY,
  daysLeft,
  displayDate,
  matches,
  reminderMessage,
  whatsappUrl,
  validityLabel,
  rupees,
  status,
  todayIST,
  type Customer,
  type Filter,
} from "./domain";
import {
  loadWorkspace,
  saveWorkspace,
  type CloudSnapshot,
} from "./lib/supabase";
import { Button } from "./components/ui/button";
import { Dialog } from "./components/ui/dialog";
import { BulkEntry } from "./components/BulkEntry";
import { CustomerPhoto } from "./components/CustomerPhoto";
import { CustomerLocation } from "./components/CustomerLocation";
import { coordinatesText, googleMapsUrl } from "./location";
import { CustomerMap } from "./components/CustomerMap";
import { CustomerForm } from "./components/CustomerForm";
import { CustomerActions, type Action } from "./components/CustomerActions";
const filters: Filter[] = ["All", "Expired", "Today", "Next 2 Days", "Active"];

function Badge({ days }: { days: number }) {
  const s = status(days);
  return (
    <span className={`badge ${s.tone}`}>
      <span className="status-dot" />
      {s.label}
    </span>
  );
}
function Avatar({customer}:{customer:Customer}) { return <CustomerPhoto customer={customer}/>; }
function App({
  initialSnapshot,
  onSignOut,
  operatorEmail,
}: {
  initialSnapshot: CloudSnapshot;
  onSignOut: () => Promise<void>;
  operatorEmail: string;
}) {
  const [customers, setCustomers] = useState(initialSnapshot.customers);
  const [storageError, setStorageError] = useState<string | null>(null);
  const [cloudBusy, setCloudBusy] = useState(false);
  const [legacy] = useState(() => {
    try {
      return localStorage.getItem(STORAGE_KEY) ? readCustomers() : null;
    } catch {
      return null;
    }
  });
  const importable =
    legacy?.customers.filter(
      (c) => !customers.some((x) => x.id === c.id || x.mobile === c.mobile),
    ) ?? [];
  async function importLegacy() {
    if (!importable.length) return;
    if (await commit([...customers, ...importable]))
      toast.success(`Imported ${importable.length} browser customers`);
  }

  const revision = useRef(initialSnapshot.revision),
    busyRef = useRef(false);
  async function commit(next: Customer[]) {
    if (busyRef.current) return false;
    busyRef.current = true;
    setCloudBusy(true);
    setStorageError(null);
    try {
      const nextRevision = await saveWorkspace(revision.current, next);
      revision.current = nextRevision;
      setCustomers(next);
      return true;
    } catch (e) {
      setStorageError(
        e instanceof Error
          ? e.message
          : "Cloud save failed. Check your connection and try again.",
      );
      toast.error("Save not confirmed. Refresh customers before retrying.");
      return false;
    } finally {
      busyRef.current = false;
      setCloudBusy(false);
    }
  }
  async function refreshCloud() {
    if (busyRef.current) return;
    busyRef.current = true;
    setCloudBusy(true);
    try {
      const cloud = await loadWorkspace();
      revision.current = cloud.revision;
      setCustomers(cloud.customers);
      setToday(todayIST());
      setPage(1);
      setStorageError(null);
      toast.success("Customers refreshed from Supabase");
    } catch (e) {
      const message = e instanceof Error ? e.message : "Could not refresh customers. Try again.";
      setStorageError(message);
      toast.error(message);
    } finally {
      busyRef.current = false;
      setCloudBusy(false);
    }
  }
  const [today, setToday] = useState(todayIST);
  const [filter, setFilter] = useState<Filter>("All");
  const [search, setSearch] = useState("");
  const [connection, setConnection] = useState("All connections");
  const [ascending, setAscending] = useState(true);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [view, setView] = useState<"dashboard" | "reminders">(() =>
    location.hash === "#reminders" ? "reminders" : "dashboard",
  );
  const [dialog, setDialog] = useState<{
    action: Action | "add" | "bulk" | "help";
    id?: string;
  } | null>(null);
  const selected = customers.find((c) => c.id === dialog?.id);
  useEffect(() => {
    const tick = () => setToday(todayIST());
    const timer = setInterval(tick, 30000);
    window.addEventListener("focus", tick);
    document.addEventListener("visibilitychange", tick);
    return () => {
      clearInterval(timer);
      window.removeEventListener("focus", tick);
      document.removeEventListener("visibilitychange", tick);
    };
  }, []);
  useEffect(() => {
    const update = () =>
      setView(location.hash === "#reminders" ? "reminders" : "dashboard");
    window.addEventListener("hashchange", update);
    return () => window.removeEventListener("hashchange", update);
  }, []);
  const counts = useMemo(
    () =>
      Object.fromEntries(
        filters.map((f) => [
          f,
          customers.filter((c) => matches(c, f, today)).length,
        ]),
      ) as Record<Filter, number>,
    [customers, today],
  );
  const due = useMemo(
    () =>
      customers
        .filter((c) => daysLeft(c.expiryDate, today) <= 2)
        .sort((a, b) => a.expiryDate.localeCompare(b.expiryDate)),
    [customers, today],
  );
  const filtered = useMemo(
    () =>
      customers
        .filter(
          (c) =>
            matches(c, filter, today) &&
            (connection === "All connections" || c.connection === connection) &&
            `${c.name} ${c.mobile} ${c.alternate} ${c.location} ${c.plan}`
              .toLowerCase()
              .includes(search.toLowerCase().trim()),
        )
        .sort(
          (a, b) =>
            (ascending ? 1 : -1) * a.expiryDate.localeCompare(b.expiryDate),
        ),
    [customers, filter, today, connection, search, ascending],
  );
  const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const currentPage = Math.min(page, pages);
  const visible = filtered.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize,
  );
  function changeFilter(f: Filter) {
    setFilter(f);
    setPage(1);
    if (view === "reminders") {
      location.hash = "dashboard";
      setView("dashboard");
    }
  }
  const action = (action: Action, c: Customer) =>
    setDialog({ action, id: c.id });
  async function save(c: Customer) {
    const existing = customers.some((x) => x.id === c.id);
    const next = existing
      ? customers.map((x) => (x.id === c.id ? c : x))
      : [...customers, c];
    if (!(await commit(next))) return;
    setDialog(null);
    toast.success(
      dialog?.action === "renew"
        ? `Recharge renewed for ${c.name}`
        : existing
          ? "Customer updated"
          : "Customer added",
    );
  }
  async function markReminder(c: Customer) {
    if (
      !(await commit(
        customers.map((x) =>
          x.id === c.id
            ? {
                ...x,
                reminders: [
                  ...x.reminders,
                  { sentAt: new Date().toISOString() },
                ],
              }
            : x,
        ),
      ))
    )
      return;
    toast.success(
      c.demo ? "Demo reminder marked as sent" : "Reminder marked as sent",
    );
  }
  function exportCSV() {
    const blob = new Blob([csv(filtered)], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `fiberdesk-customers-${today}.csv`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast.success(`Exported ${filtered.length} customers`);
  }
  const close = () => setDialog(null);
  const reminderDate = (c: Customer) =>
    c.reminders.at(-1)
      ? displayDate(todayIST(new Date(c.reminders.at(-1)!.sentAt)))
      : "Not sent yet";
  const stats = [
    {
      filter: "All" as Filter,
      label: "Total customers",
      sub: "Across both connections",
      Icon: Users,
      tone: "blue",
    },
    {
      filter: "Expired" as Filter,
      label: "Expired recharges",
      sub: "Ready for a follow-up",
      Icon: Clock3,
      tone: "red",
    },
    {
      filter: "Today" as Filter,
      label: "Expiring today",
      sub: "Keep them connected",
      Icon: CalendarDays,
      tone: "amber",
    },
    {
      filter: "Next 2 Days" as Filter,
      label: "Next 2 days",
      sub: `${displayDate(addDays(today, 1)).slice(0, 6)} – ${displayDate(addDays(today, 2)).slice(0, 6)}`,
      Icon: Bell,
      tone: "amber",
    },
  ];
  return (
    <>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <header className="app-header">
        <div className="header-inner">
          <a
            className="brand"
            href="#dashboard"
            aria-label="FiberDesk dashboard"
          >
            <span className="brand-mark">
              <Wifi size={25} />
            </span>
            <span>
              FiberDesk
              <span className="brand-caption">Customer & recharge desk</span>
            </span>
          </a>
          <nav aria-label="Main navigation">
            <a
              href="#dashboard"
              className={
                view === "dashboard" ? "nav-link selected" : "nav-link"
              }
              aria-current={view === "dashboard" ? "page" : undefined}
            >
              <LayoutDashboard size={17} />
              Dashboard
            </a>
            <a
              href="#reminders"
              className={
                view === "reminders" ? "nav-link selected" : "nav-link"
              }
              aria-current={view === "reminders" ? "page" : undefined}
            >
              <Bell size={17} />
              Reminders
              {due.length > 0 ? (
                <span className="nav-count">{due.length}</span>
              ) : null}
            </a>
          </nav>
          <div className="header-end">
            <Button variant="ghost" size="icon" disabled={cloudBusy} onClick={refreshCloud}
              aria-label={cloudBusy ? "Refreshing customers" : "Refresh customers"} title="Refresh customers">
              <RefreshCw size={19} className={cloudBusy ? "refresh-spinning" : ""} />
            </Button>
            <span className="local-note">
              <ShieldCheck size={16} />
              Cloud workspace
            </span>
            <button
              className="operator-avatar"
              aria-label="About your cloud workspace"
              onClick={() => setDialog({ action: "help" })}
            >
              FD
            </button>
          </div>
        </div>
      </header>
      <main id="main" className="main" aria-busy={cloudBusy}>
        <div className="page-heading">
          <div>
            <div className="heading-line">
              <h1>
                {view === "dashboard" ? "Dashboard" : "Recharge reminders"}
              </h1>
              <span className="workspace-label">JioFiber & AirFiber</span>
            </div>
            <p>
              {view === "dashboard"
                ? `Today, ${displayDate(today)}`
                : "A simple follow-up queue to keep your customers connected."}
            </p>
          </div>
          <div className="heading-actions">
            <Button variant="outline" disabled={cloudBusy} onClick={()=>setDialog({action:'bulk'})}>Bulk entry</Button>
            <span className="today-date">
              <CalendarDays size={16} />
              {displayDate(today)}
            </span>
            <Button
              disabled={cloudBusy}
              onClick={() => setDialog({ action: "add" })}
            >
              <Plus size={18} />
              Add customer
            </Button>
          </div>
        </div>
        {storageError ? (
          <div role="alert" className="storage-error">
            <TriangleAlert size={20} />
            {storageError}
          </div>
        ) : null}
        {view === "dashboard" ? (
          <>
            <section className="dashboard-welcome" aria-label="Workspace overview">
              <div className="welcome-copy">
                <span className="welcome-eyebrow">YOUR FIBERDESK WORKSPACE</span>
                <h2>Every connection, in good hands.</h2>
                <p>Keep customer details organised and stay one step ahead of every recharge.</p>
                <div className="welcome-meta">
                  <span><Users size={15} /> {customers.length} customers</span>
                  <span><Bell size={15} /> {due.length} follow-ups due</span>
                </div>
              </div>
              <div className="welcome-art" aria-hidden="true">
                <span className="welcome-ring welcome-ring-one" />
                <span className="welcome-ring welcome-ring-two" />
                <span className="welcome-wifi"><Wifi size={38} /></span>
                <span className="welcome-signal signal-one" />
                <span className="welcome-signal signal-two" />
              </div>
            </section>
            <section className="stats-grid" aria-label="Customer overview">
              {stats.map(({ filter: f, label, sub, Icon, tone }) => (
                <button
                  key={f}
                  className={`stat-card ${filter === f ? "stat-selected" : ""}`}
                  onClick={() => changeFilter(f)}
                  aria-pressed={filter === f}
                >
                  <div className="stat-top">
                    <span>{label}</span>
                    <Icon size={18} className={`ink-${tone}`} />
                  </div>
                  <div className="stat-value">
                    {counts[f]}
                    <span className={`stat-foot ink-${tone}`}>
                      {f === "Expired" && counts[f] > 0
                        ? "Need attention"
                        : f === "Today" && counts[f] > 0
                          ? "Due today"
                          : ""}
                    </span>
                  </div>
                  <div className="stat-bottom">
                    <span>{sub}</span>
                    <ChevronRight size={15} />
                  </div>
                </button>
              ))}
            </section>
            <CustomerMap customers={customers} today={today}/>
            <section
              className="reminder-section"
              aria-labelledby="reminder-heading"
            >
              <div className="section-heading">
                <div>
                  <h2 id="reminder-heading">
                    <Bell size={18} />
                    Recharge reminders{" "}
                    <span className="count-badge">{due.length}</span>
                  </h2>
                  <p>
                    {due.length
                      ? `${due.length} customers need a little nudge. Follow up manually or renew their recharge.`
                      : "You’re all caught up. No recharges expire in the next two days."}
                  </p>
                </div>
                <Button
                  variant="ghost"
                  onClick={() => {
                    location.hash = "reminders";
                    setView("reminders");
                  }}
                >
                  View all reminders
                  <ChevronRight size={16} />
                </Button>
              </div>
              {due.length ? (
                <div className="reminder-grid">
                  {due.slice(0, 3).map((c) => (
                    <article className="reminder-card" key={c.id}>
                      <div className="reminder-card-top">
                        <Badge days={daysLeft(c.expiryDate, today)} />
                        <span className="demo-tag">{c.demo ? "Demo" : ""}</span>
                      </div>
                      <div className="reminder-person">
                        <Avatar customer={c} />
                        <div>
                          <button
                            className="text-button customer-name"
                            onClick={() => action("view", c)}
                          >
                            {c.name}
                          </button>
                          <p>
                            {c.location} · {c.connection}
                          </p>
                        </div>
                      </div>
                      <div className="reminder-meta">
                        <span>
                          {daysLeft(c.expiryDate, today) < 0
                            ? "Expired"
                            : "Expires"}{" "}
                          {displayDate(c.expiryDate).slice(0, 6)}
                        </span>
                        <span>
                          {c.reminders.length
                            ? "Reminder marked sent"
                            : "No reminder yet"}
                        </span>
                      </div>
                      <div className="reminder-actions">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => markReminder(c)}
                          disabled={c.reminders.some(
                            (r) => todayIST(new Date(r.sentAt)) === today,
                          )}
                        >
                          <Check size={16} />
                          {c.reminders.some(
                            (r) => todayIST(new Date(r.sentAt)) === today,
                          )
                            ? "Marked today"
                            : "Mark reminder sent"}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => action("renew", c)}
                        >
                          <RefreshCw size={15} />
                          Renew
                        </Button>
                      </div>
                    </article>
                  ))}
                </div>
              ) : (
                <div className="compact-empty">
                  <Check size={20} />
                  All customers are up to date.
                </div>
              )}
            </section>
            <section
              className="customer-section"
              aria-labelledby="customers-heading"
            >
              <div className="customer-section-heading">
                <div>
                  <h2 id="customers-heading">
                    Customers{" "}
                    <span className="count-badge">{customers.length}</span>
                  </h2>
                  <p>Your connections, organised in one place.</p>
                </div>
                <Button variant="outline" onClick={exportCSV}>
                  <Download size={16} />
                  Export CSV
                </Button>
              </div>
              <div className="list-toolbar">
                <div className="search-wrap">
                  <Search size={18} />
                  <input
                    aria-label="Search customers"
                    placeholder="Search name, mobile or location…"
                    value={search}
                    onChange={(e) => {
                      setSearch(e.target.value);
                      setPage(1);
                    }}
                  />
                  {search ? (
                    <button
                      className="clear-search"
                      aria-label="Clear search"
                      onClick={() => setSearch("")}
                    >
                      ×
                    </button>
                  ) : null}
                </div>
                <div className="connection-filter">
                  <SlidersHorizontal size={16} />
                  <select
                    aria-label="Filter by connection"
                    value={connection}
                    onChange={(e) => {
                      setConnection(e.target.value);
                      setPage(1);
                    }}
                  >
                    <option>All connections</option>
                    <option>JioFiber</option>
                    <option>Jio AirFiber</option>
                  </select>
                </div>
                <select
                  className="expiry-sort"
                  aria-label="Sort by expiry"
                  value={ascending ? "oldest" : "newest"}
                  onChange={(e) => {
                    setAscending(e.target.value === "oldest");
                    setPage(1);
                  }}
                >
                  <option value="oldest">Oldest expiry first</option>
                  <option value="newest">Newest expiry first</option>
                </select>
              </div>
              <div className="filter-row">
                <div
                  className="filter-tabs"
                  role="group"
                  aria-label="Filter by expiry status"
                >
                  {filters.map((f) => (
                    <button
                      key={f}
                      className={
                        filter === f ? "filter-tab active" : "filter-tab"
                      }
                      onClick={() => changeFilter(f)}
                      aria-pressed={filter === f}
                    >
                      {f}
                      {f === "All" ? <span>{counts.All}</span> : null}
                    </button>
                  ))}
                </div>
                <span className="sort-caption">
                  {ascending ? "Earliest expiry first" : "Latest expiry first"}
                </span>
              </div>
              {filtered.length ? (
                <>
                  <div className="desktop-table">
                    <table>
                      <thead>
                        <tr>
                          <th scope="col">Customer</th>
                          <th scope="col">Location</th>
                          <th scope="col">Connection</th>
                          <th scope="col" className="plan-col">
                            Plan / amount
                          </th>
                          <th
                            scope="col"
                            aria-sort={ascending ? "ascending" : "descending"}
                          >
                            <button
                              className="sort-button"
                              onClick={() => setAscending((a) => !a)}
                            >
                              Expiry date
                              <ArrowUpDown size={14} />
                            </button>
                          </th>
                          <th scope="col">Days left</th>
                          <th scope="col">Status</th>
                          <th scope="col" className="action-th">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {visible.map((c) => {
                          const d = daysLeft(c.expiryDate, today);
                          return (
                            <tr key={c.id}>
                              <td>
                                <div className="customer-cell">
                                  <Avatar customer={c} />
                                  <div>
                                    <div className="name-line">
                                      <button
                                        className="text-button customer-name"
                                        onClick={() => action("view", c)}
                                      >
                                        {c.name}
                                      </button>
                                      {c.demo ? (
                                        <span className="demo-tag">Demo</span>
                                      ) : null}
                                    </div>
                                    <span className="phone">
                                      {c.demo
                                        ? "Test number"
                                        : `+91 ${c.mobile}`}
                                    </span>
                                  </div>
                                </div>
                              </td>
                              <td><CustomerLocation customer={c}/></td>
                              <td>
                                <span className="connection-label">
                                  {c.connection === "JioFiber" ? (
                                    <Wifi size={14} />
                                  ) : (
                                    <Router size={14} />
                                  )}
                                  <span>{c.connection}</span>
                                </span>
                              </td>
                              <td className="plan-col">
                                <span className="plan-name">
                                  {c.plan || "No plan specified"}
                                </span>
                                <span className="amount">
                                  {rupees(c.amount)}
                                </span>
                              </td>
                              <td className="date-cell">
                                {displayDate(c.expiryDate)}
                              </td>
                              <td>
                                <span
                                  className={
                                    d < 0
                                      ? "ink-red"
                                      : d <= 2
                                        ? "ink-amber"
                                        : "muted"
                                  }
                                >
                                  {d < 0
                                    ? `${Math.abs(d)}d overdue`
                                    : d === 0
                                      ? "Today"
                                      : `${d} day${d === 1 ? "" : "s"}`}
                                </span>
                              </td>
                              <td>
                                <Badge days={d} />
                              </td>
                              <td>
                                <div className="desktop-customer-actions">
                                <Button size="icon" variant="ghost" title="Mark reminder sent"
                                  aria-label={`Mark reminder sent for ${c.name}`}
                                  disabled={cloudBusy || c.reminders.some(r=>todayIST(new Date(r.sentAt))===today)}
                                  onClick={()=>markReminder(c)}><Check size={17}/></Button>
                                <CustomerActions
                                  customer={c}
                                  onAction={action}
                                />
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                  <div className="mobile-customer-list">
                    {visible.map((c) => (
                      <article className="mobile-customer" key={c.id}>
                        <div className="mobile-card-top">
                          <div className="customer-cell">
                            <Avatar customer={c} />
                            <div>
                              <button
                                className="text-button customer-name"
                                onClick={() => action("view", c)}
                              >
                                {c.name}
                              </button>
                              <span className="phone">
                                {c.demo
                                  ? "Demo · Test number"
                                  : `+91 ${c.mobile}`}
                              </span>
                            </div>
                          </div>
                          <Badge days={daysLeft(c.expiryDate, today)} />
                        </div>
                        <div className="mobile-details">
                          <CustomerLocation customer={c}/>
                          <span>{c.connection}</span>
                          <span>
                            {c.plan || "No plan"} · {rupees(c.amount)}
                          </span>
                          <span>Expiry {displayDate(c.expiryDate)}</span>
                          <span className="card-validity">
                            {validityLabel(c)} ·{" "}
                            {daysLeft(c.expiryDate, today) < 0
                              ? `${Math.abs(daysLeft(c.expiryDate, today))} days overdue`
                              : daysLeft(c.expiryDate, today) === 0
                                ? "Expires today"
                                : `${daysLeft(c.expiryDate, today)} days remaining`}
                          </span>
                        </div>
                        <div className="mobile-card-bottom">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => markReminder(c)}
                            disabled={c.reminders.some(
                              (r) => todayIST(new Date(r.sentAt)) === today,
                            )}
                          >
                            <Check size={16} />
                            {c.reminders.some(
                              (r) => todayIST(new Date(r.sentAt)) === today,
                            )
                              ? "Marked today"
                              : "Mark reminder sent"}
                          </Button>
                          <CustomerActions customer={c} onAction={action} />
                        </div>
                      </article>
                    ))}
                  </div>
                </>
              ) : (
                <div className="empty-state">
                  <Inbox size={32} />
                  <h3>
                    {customers.length
                      ? "No matching customers"
                      : "Your first connection starts here"}
                  </h3>
                  <p>
                    {customers.length
                      ? "Try another name, mobile number, or filter."
                      : "Add a customer to track their recharge and send reminders."}
                  </p>
                  <Button
                    variant="outline"
                    onClick={() => {
                      if (customers.length) {
                        setSearch("");
                        setFilter("All");
                        setConnection("All connections");
                      } else setDialog({ action: "add" });
                    }}
                  >
                    {customers.length ? "Clear filters" : "Add customer"}
                  </Button>
                </div>
              )}
              <div className="table-footer">
                <span aria-live="polite">
                  {filtered.length
                    ? `${(currentPage - 1) * pageSize + 1}–${Math.min(currentPage * pageSize, filtered.length)} of ${filtered.length} customers`
                    : "0 customers"}
                </span>
                <label className="page-size">Customers per page
                  <select aria-label="Customers per page" value={pageSize} onChange={e=>{setPageSize(Number(e.target.value));setPage(1);}}>
                    {[25,50,100].map(size=><option key={size} value={size}>1–{size}</option>)}
                  </select>
                </label>
                <div className="pagination">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={currentPage <= 1}
                    onClick={() => setPage((p) => p - 1)}
                  >
                    <ChevronLeft size={15} />
                    Previous
                  </Button>
                  <span>
                    {currentPage} / {pages}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={currentPage >= pages}
                    onClick={() => setPage((p) => p + 1)}
                  >
                    Next
                    <ChevronRight size={15} />
                  </Button>
                </div>
              </div>
            </section>
          </>
        ) : (
          <section className="full-reminders">
            <div className="reminders-intro">
              <div>
                <h2>
                  Follow-up queue{" "}
                  <span className="count-badge">{due.length}</span>
                </h2>
                <p>
                  Oldest expiry first. Mark a reminder only after you’ve sent
                  it.
                </p>
              </div>
              <span className="badge blue">Manual sending only</span>
            </div>
            {due.length ? (
              due.map((c) => (
                <article className="queue-row" key={c.id}>
                  <div className="customer-cell">
                    <Avatar customer={c} />
                    <div>
                      <div className="name-line">
                        <button
                          className="text-button customer-name"
                          onClick={() => action("view", c)}
                        >
                          {c.name}
                        </button>
                        {c.demo ? <span className="demo-tag">Demo</span> : null}
                      </div>
                      <span className="phone">
                        {c.location} · {c.connection}
                      </span>
                    </div>
                  </div>
                  <div>
                    <Badge days={daysLeft(c.expiryDate, today)} />
                    <span className="queue-expiry">
                      Expiry {displayDate(c.expiryDate)}
                    </span>
                  </div>
                  <div className="queue-last">
                    <span>Last reminder</span>
                    <strong>{reminderDate(c)}</strong>
                  </div>
                  <div className="queue-actions">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => markReminder(c)}
                      disabled={c.reminders.some(
                        (r) => todayIST(new Date(r.sentAt)) === today,
                      )}
                    >
                      <Check size={16} />
                      {c.reminders.some(
                        (r) => todayIST(new Date(r.sentAt)) === today,
                      )
                        ? "Marked today"
                        : "Mark sent"}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => action("renew", c)}
                    >
                      <RefreshCw size={16} />
                      Renew
                    </Button>
                  </div>
                </article>
              ))
            ) : (
              <div className="empty-state">
                <Check size={32} />
                <h3>You’re all caught up</h3>
                <p>No expired or upcoming recharges need a reminder.</p>
              </div>
            )}
          </section>
        )}
        <div className="cloud-toolbar">
          <Button variant="outline" disabled={cloudBusy} onClick={refreshCloud}>
            <RefreshCw size={16} />
            {cloudBusy ? "Syncing…" : "Refresh customers"}
          </Button>
          <Button
            variant="ghost"
            disabled={cloudBusy}
            onClick={async () => {
              try {
                await onSignOut();
              } catch {
                toast.error("Could not sign out. Please try again.");
              }
            }}
          >
            Sign out
          </Button>
          <span>{operatorEmail}</span>
        </div>
        <footer className="app-footer">
          <span>
            <ShieldCheck size={14} />
            {storageError ? "Storage needs attention" : "Saved to Supabase"}
            <span className="footer-dot">·</span>Dates in Asia/Kolkata
          </span>
          <button onClick={() => setDialog({ action: "help" })}>
            About this workspace
            <Info size={14} />
          </button>
        </footer>
      </main>
      <Dialog
        open={!!dialog}
        onOpenChange={(open) => {
          if (!open) {
            if (cloudBusy) return;
            if (
              (dialog?.action === "add" ||
                dialog?.action === "edit" ||
                dialog?.action === "renew") &&
              !confirm("Close this form? Unsaved changes will be lost.")
            )
              return;
            close();
          }
        }}
        title={
          dialog?.action === "bulk" ? "Bulk customer entry" : dialog?.action === "add"
            ? "Add customer"
            : dialog?.action === "edit"
              ? "Edit customer"
              : dialog?.action === "renew"
                ? "Renew recharge"
                : dialog?.action === "message"
                  ? selected?.demo
                    ? "Demo WhatsApp preview"
                    : "WhatsApp reminder"
                  : dialog?.action === "delete"
                    ? "Delete customer?"
                    : dialog?.action === "help"
                      ? "Your cloud workspace"
                      : (selected?.name ?? "Customer")
        }
        description={
          dialog?.action === "bulk" ? "Import multiple customers together. Review every row before saving." : dialog?.action === "add"
            ? "Enter the basics. Expiry and days remaining are calculated for you."
            : dialog?.action === "edit"
              ? "Keep this customer’s contact and recharge details up to date."
              : dialog?.action === "renew"
                ? "Update the plan and start a fresh recharge period."
                : dialog?.action === "message"
                  ? "Review the message. You decide when to send it."
                  : dialog?.action === "delete"
                    ? "This removes the customer and their recharge history."
                    : dialog?.action === "help"
                      ? "A simple desk for your connections."
                      : `${selected?.connection ?? ""} customer details`
        }
        wide={["add", "bulk", "edit", "renew", "view"].includes(dialog?.action ?? "")}
      >
        {dialog?.action === 'bulk' && <BulkEntry customers={customers} saving={cloudBusy} onCancel={close} onSave={async rows=>{const saved=await commit([...customers,...rows]);if(saved)toast.success(`Imported ${rows.length} customers`);return saved;}}/>}
        {dialog?.action === "add" ||
        (selected &&
          (dialog?.action === "edit" || dialog?.action === "renew")) ? (
          <CustomerForm
            key={`${dialog?.action}-${selected?.id ?? "new"}`}
            customers={customers}
            customer={dialog?.action === "add" ? undefined : selected}
            renew={dialog?.action === "renew"}
            onSave={save}
            saving={cloudBusy}
            onCancel={close}
          />
        ) : null}
        {selected && dialog?.action === "message" ? (
          <>
            <div className="dialog-body">
              {selected.demo ? (
                <div className="demo-contact-notice">
                  Fictional demo customer. This preview cannot open WhatsApp.
                </div>
              ) : (
                <p className="message-recipient">
                  To {selected.name} · +91 {selected.mobile}
                </p>
              )}
              <pre className="message-preview">
                {reminderMessage(selected, today)}
              </pre>
              <p className="message-help muted">
                {selected.demo
                  ? "Demo numbers never open WhatsApp."
                  : "Open WhatsApp, review the message and send it yourself. Then mark the reminder as sent."}
              </p>
              <p className="message-help muted">
                Last reminder: {reminderDate(selected)}
              </p>
            </div>
            <footer className="dialog-footer">
              <Button
                variant="outline"
                onClick={() => markReminder(selected)}
                disabled={selected.reminders.some(
                  (r) => todayIST(new Date(r.sentAt)) === today,
                )}
              >
                <Check size={16} />
                Mark reminder sent
              </Button>
              {whatsappUrl(selected, today) ? (
                <Button asChild>
                  <a
                    href={whatsappUrl(selected, today)!}
                    
                  >
                    <MessageCircle size={16} />
                    Open WhatsApp
                    <ExternalLink size={14} />
                  </a>
                </Button>
              ) : (
                <Button onClick={close}>Done</Button>
              )}
            </footer>
          </>
        ) : null}
        {selected && dialog?.action === "delete" ? (
          <>
            <div className="dialog-body">
              <p>
                Delete <strong>{selected.name}</strong> from FiberDesk? This
                action cannot be undone.
              </p>
            </div>
            <footer className="dialog-footer">
              <Button variant="outline" onClick={close}>
                Keep customer
              </Button>
              <Button
                variant="destructive"
                disabled={cloudBusy}
                onClick={async () => {
                  if (
                    !(await commit(
                      customers.filter((c) => c.id !== selected.id),
                    ))
                  )
                    return;
                  close();
                  toast.success("Customer deleted");
                }}
              >
                Delete customer
              </Button>
            </footer>
          </>
        ) : null}
        {selected && dialog?.action === "view" ? (
          <>
            <div className="dialog-body">
              <div className="detail-identity">
                <Avatar customer={selected} />
                <div>
                  <Badge days={daysLeft(selected.expiryDate, today)} />
                  {selected.demo ? (
                    <span className="demo-tag">Demonstration customer</span>
                  ) : null}
                </div>
              </div>
              <dl className="details-grid">
                {[
                  [
                    "Mobile",
                    selected.demo
                      ? `${selected.mobile} (fictional)`
                      : `+91 ${selected.mobile}`,
                  ],
                  ["Alternate mobile", selected.alternate || "—"],
                  ["Location", selected.location || "—"],
                  ["Latitude, longitude", coordinatesText(selected) || "—"],
                  ["Connection", selected.connection],
                  ["Plan", selected.plan || "—"],
                  ["Recharge amount", rupees(selected.amount)],
                  ["Activation date", displayDate(selected.rechargeDate)],
                  ["Validity", validityLabel(selected)],
                  ["Expiry date", displayDate(selected.expiryDate)],
                  ["Last reminder", reminderDate(selected)],
                ].map(([label, value]) => (
                  <div key={label}>
                    <dt>{label}</dt>
                    <dd>{value}</dd>
                  </div>
                ))}
              </dl>
              {googleMapsUrl(selected) && <div className="detail-map"><CustomerLocation customer={selected}/></div>}
              <div className="detail-notes">
                <h3>Notes</h3>
                <p>{selected.notes || "No notes added."}</p>
              </div>
              <div className="history">
                <h3>Activity</h3>
                {!selected.renewals.length && !selected.reminders.length ? (
                  <p className="muted">
                    No renewals or reminders recorded yet.
                  </p>
                ) : (
                  <ul>
                    {[
                      ...selected.renewals.map((r) => ({
                        at: r.recordedAt,
                        text: `Recharge renewed · ${r.plan || "Plan"} · ${validityLabel(r)} · ${rupees(r.amount)}`,
                      })),
                      ...selected.reminders.map((r) => ({
                        at: r.sentAt,
                        text: `${selected.demo ? "Demo reminder" : "Reminder"} marked sent`,
                      })),
                    ]
                      .sort((a, b) => b.at.localeCompare(a.at))
                      .map((r, i) => (
                        <li key={i}>
                          <Check size={15} />
                          <span>
                            {r.text}
                            <small>
                              {displayDate(todayIST(new Date(r.at)))}
                            </small>
                          </span>
                        </li>
                      ))}
                  </ul>
                )}
              </div>
            </div>
            <footer className="dialog-footer">
              <Button
                variant="outline"
                onClick={() => action("edit", selected)}
              >
                Edit customer
              </Button>
              <Button onClick={() => action("renew", selected)}>
                <RefreshCw size={16} />
                Renew recharge
              </Button>
            </footer>
          </>
        ) : null}
        {dialog?.action === "help" ? (
          <>
            <div className="dialog-body help-content">
              <div className="help-item">
                <ShieldCheck />
                <div>
                  <h3>Your data is saved in Supabase</h3>
                  <p>
                    Customers, renewals and reminder history are saved securely
                    in Supabase. Use the same operator email on another device
                    to access them. Refresh to get the latest changes.
                  </p>
                </div>
              </div>
              {legacy ? (
                <div className="help-item">
                  <CloudUpload size={20} />
                  <div>
                    <h3>Browser migration backup</h3>
                    <p>
                      {legacy.error ||
                        (importable.length
                          ? `${importable.length} customers saved in this browser are not in Supabase. Import them without changing existing cloud customers.`
                          : "All matching browser customers are already in your cloud workspace. Your original browser copy is kept as a backup.")}
                    </p>
                    {importable.length ? (
                      <Button
                        variant="outline"
                        disabled={cloudBusy}
                        onClick={importLegacy}
                      >
                        Import {importable.length} customers
                      </Button>
                    ) : null}
                  </div>
                </div>
              ) : null}
              <div className="help-item">
                <Check />
                <div>
                  <h3>Manual follow-ups & WhatsApp</h3>
                  <p>
                    Open WhatsApp to review and send a message yourself, or
                    follow up through your preferred method. Then mark the
                    reminder as sent. Demo numbers only show a preview.
                  </p>
                </div>
              </div>
              <div className="help-item">
                <Users />
                <div>
                  <h3>Ten customers to try things out</h3>
                  <p>
                    Records labelled Demo are fictional and use test numbers.
                    You can edit or delete them, then add your own customers.
                  </p>
                </div>
              </div>
              <p className="muted">
                Independent customer management tool. Not affiliated with
                Reliance Jio.
              </p>
            </div>
            <footer className="dialog-footer">
              <Button onClick={close}>Got it</Button>
            </footer>
          </>
        ) : null}
      </Dialog>
      <Toaster position="bottom-right" richColors closeButton />
    </>
  );
}
export default App;
