import { parseCoordinates } from './location';
import { addDays, addCalendarMonths, daysLeft, todayIST, validDate, type Customer } from './domain';
export const bulkTemplate = 'Name,Number,Alternate Number,Plan,Activation Date,Validity,Location,Coordinates\nExample Customer,9876543210,,30 Mbps,2026-11-20,1 month,New Town,"22.736390,88.373882"';
export function parseRows(text: string): string[][] {
  const rows: string[][] = []; let row: string[] = [], cell = '', quoted = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (c === '"') { if (quoted && text[i + 1] === '"') { cell += '"'; i++; } else quoted = !quoted; }
    else if (!quoted && (c === ',' || c === '\t')) { row.push(cell.trim()); cell = ''; }
    else if (!quoted && (c === '\n' || c === '\r')) { if (c === '\r' && text[i+1] === '\n') i++; row.push(cell.trim()); if(row.some(Boolean)) rows.push(row); row=[];cell=''; }
    else cell += c;
  }
  if (quoted) throw new Error('A quoted cell is missing its closing quote.');
  row.push(cell.trim()); if (row.some(Boolean)) rows.push(row); return rows;
}
export function previewBulk(text: string, existing: Customer[]) {
 const rows = parseRows(text.replace(/^\uFEFF/, '')); if (!rows.length) return [];
 const header = rows.shift()!.map(x=>x.toLowerCase().replace(/[^a-z]/g,''));
 const index = (names:string[]) => header.findIndex(h=>names.includes(h));
 const nameIndex=index(['name','customername']), phoneIndex=index(['number','mobile','mobilenumber']);
 if(nameIndex < 0 || phoneIndex < 0) throw new Error('Include a header row with Name and Number columns. Download the template for all supported columns.');
 if(rows.length>500) throw new Error('Import up to 500 customers at a time.');
 const seen = new Set(existing.map(c=>c.mobile));
 return rows.map((row,i)=>{
  const get=(...names:string[])=>row[index(names)] || '';
  const name=row[nameIndex]||'', mobile=(row[phoneIndex]||'').replace(/[\s()-]/g,'').replace(/^(\+91|91(?=\d{10}$))/,'');
  const errors:string[]=[];
  if(!name.trim()) errors.push('Name required');
  if(!/^[6-9]\d{9}$/.test(mobile)) errors.push('Invalid Indian mobile number');
  if(seen.has(mobile)) errors.push('Duplicate number'); seen.add(mobile);
  const date=get('activationdate','rechargedate')||todayIST();
  if(!validDate(date)) errors.push('Use YYYY-MM-DD for activation date');
  const duration=(get('validity')||'1 month').toLowerCase();
  const monthMatch=duration.match(/^(1|2|4|6|8|12)\s*(months?|m)$/);
  const months=monthMatch?Number(monthMatch[1]):undefined;
  const days=Number(duration.replace(/\s*days?$/,''));
  if(!months && (!Number.isInteger(days)||days<1||days>3650)) errors.push('Validity: use 28 days, 1/2/4/6/8/12 months, or days');
  const expiry=validDate(date)&&!errors.some(e=>e.startsWith('Validity')) ? months?addCalendarMonths(date,months):addDays(date,days):date;
  const coordinate=(key:string,limit:number)=>{const v=get(key);if(!v)return undefined;const n=Number(v);if(!Number.isFinite(n)||Math.abs(n)>limit) errors.push(`Invalid ${key}`);return n;};
  let coordinates: ReturnType<typeof parseCoordinates>;
  try { coordinates=parseCoordinates(get('coordinates','latitudelongitude')); } catch(error) { errors.push((error as Error).message); }
  const alternate=get('alternatenumber','alternatemobile'); if(alternate&&!/^[6-9]\d{9}$/.test(alternate)) errors.push('Invalid alternate number');
  const plan=get('plan'); if(plan&&!/^(unlimited )?(30|100)\s*mbps$/i.test(plan))errors.push('Plan must be 30 Mbps or 100 Mbps');
  const customer:Customer={id:crypto.randomUUID(),name,mobile,alternate,location:get('location','area'),latitude:coordinates?.latitude??coordinate('latitude',90),longitude:coordinates?.longitude??coordinate('longitude',180),connection:'JioFiber',plan:plan?`Unlimited ${plan.includes('100')?'100':'30'} Mbps`:'',amount:0,rechargeDate:date,expiryDate:expiry,validity:validDate(expiry)&&validDate(date)?daysLeft(expiry,date):0,validityMonths:months,notes:'',reminders:[],renewals:[],demo:false};
  return {row:i+2,customer,errors};
 });
}
