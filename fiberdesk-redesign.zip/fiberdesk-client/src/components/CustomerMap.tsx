import {useEffect,useMemo,useRef,useState} from 'react';
import type {Map as LeafletMap} from 'leaflet';
import {MapPin,Maximize2} from 'lucide-react';
import {daysLeft,displayDate,type Customer} from '../domain';
import {customerMapStatus,mapGroups,type MapStatus} from '../customer-map';
import {googleMapsUrl} from '../location';
import {Button} from './ui/button';
import 'leaflet/dist/leaflet.css';
const colors:Record<MapStatus,string>={expired:'#c92a2a',near:'#e3a008',active:'#15803d'};
const labels:Record<MapStatus,string>={expired:'Expired',near:'Near expiry',active:'Active'};
export function CustomerMap({customers,today}:{customers:Customer[];today:string}){
 const container=useRef<HTMLDivElement>(null),mapRef=useRef<LeafletMap|null>(null),fitRef=useRef<()=>void>(()=>{});
 const [error,setError]=useState(''),[loading,setLoading]=useState(true),[retry,setRetry]=useState(0),[tilesFailed,setTilesFailed]=useState(false);
 const groups=useMemo(()=>mapGroups(customers),[customers]);
 const mapped=groups.reduce((n,g)=>n+g.customers.length,0),missing=customers.length-mapped;
 const counts={expired:0,near:0,active:0};groups.forEach(g=>g.customers.forEach(c=>counts[customerMapStatus(c,today)]++));
 useEffect(()=>{
  let disposed=false;let map:LeafletMap|undefined;let observer:ResizeObserver|undefined;
  const hoverCleanups:Array<()=>void>=[];
  setLoading(true);setError('');setTilesFailed(false);
  void import('leaflet').then(L=>{
   if(disposed||!container.current)return;
   map=L.map(container.current,{scrollWheelZoom:false,zoomControl:true,fadeAnimation:false}).setView([22.73639,88.373882],12);mapRef.current=map;
   const tiles=L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors'}).addTo(map);
   tiles.on('tileerror',()=>{if(!disposed)setTilesFailed(true);});
   for(const group of groups){
    const priority:MapStatus=group.customers.some(c=>customerMapStatus(c,today)==='expired')?'expired':group.customers.some(c=>customerMapStatus(c,today)==='near')?'near':'active';
    const icon=L.divIcon({className:'customer-map-marker',iconSize:[28,34],iconAnchor:[14,32],popupAnchor:[0,-28],html:`<svg viewBox="0 0 40 48" aria-hidden="true"><path d="M20 46C16 40 3 28 3 19a17 17 0 0 1 34 0c0 9-13 21-17 27Z" fill="${colors[priority]}" stroke="white" stroke-width="3"/><circle cx="20" cy="19" r="${group.customers.length>1?11:6}" fill="white"/>${group.customers.length>1?`<text x="20" y="23" text-anchor="middle" fill="#1d2939" font-size="12" font-weight="700">${group.customers.length}</text>`:''}</svg>`});
    const popup=document.createElement('div');popup.className='customer-map-popup';
    for(const c of group.customers){const entry=document.createElement('div');entry.className='map-popup-entry';const name=document.createElement('strong');name.textContent=c.name;entry.append(name);const info=document.createElement('span');const status=customerMapStatus(c,today),days=daysLeft(c.expiryDate,today);info.textContent=`${labels[status]} · ${days<0?`${Math.abs(days)} days overdue`:days===0?'Expires today':`${days} days left`}`;info.style.color=colors[status];entry.append(info);const plan=document.createElement('span');plan.textContent=`${c.plan||c.connection} · Expires ${displayDate(c.expiryDate)}`;entry.append(plan);const link=document.createElement('a');link.href=googleMapsUrl(c)!;link.target='_blank';link.rel='noopener noreferrer';link.textContent='Open in Google Maps';entry.append(link);popup.append(entry);}
    const title=group.customers.length===1?`${group.customers[0].name} — ${labels[priority]}`:`${group.customers.length} customers at this location — ${labels[priority]}`;
    const marker=L.marker([group.latitude,group.longitude],{icon,title,alt:title,keyboard:true,riseOnHover:true,zIndexOffset:priority==='expired'?1000:priority==='near'?500:0}).addTo(map).bindPopup(popup,{maxWidth:300,maxHeight:260});
    let closeTimer:ReturnType<typeof setTimeout>|undefined;
    const cancelClose=()=>{if(closeTimer!==undefined){clearTimeout(closeTimer);closeTimer=undefined;}};
    const isHoverDevice=()=>window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const closeSoon=()=>{if(!isHoverDevice())return;cancelClose();closeTimer=setTimeout(()=>{if(!disposed)marker.closePopup();},220);};
    marker.on('mouseover',()=>{if(!isHoverDevice())return;cancelClose();const details=marker.getPopup();if(details)details.options.autoPan=false;marker.openPopup();if(details)details.options.autoPan=true;});
    marker.on('mouseout',closeSoon);
    popup.addEventListener('mouseenter',cancelClose);
    popup.addEventListener('mouseleave',closeSoon);
    popup.addEventListener('focusin',cancelClose);
    marker.on('popupclose',cancelClose);
    hoverCleanups.push(cancelClose);
   }
   const fit=()=>{if(!map)return;if(groups.length)map.fitBounds(L.latLngBounds(groups.map(g=>[g.latitude,g.longitude] as [number,number])),{padding:[36,36],maxZoom:15,animate:false});else map.setView([22.73639,88.373882],12);};fitRef.current=fit;fit();
   observer=new ResizeObserver(()=>map?.invalidateSize({animate:false}));observer.observe(container.current);setLoading(false);
  }).catch(()=>{if(!disposed){setError('The map could not load. Check your connection and try again.');setLoading(false);}});
  return()=>{disposed=true;hoverCleanups.forEach(cleanup=>cleanup());observer?.disconnect();map?.remove();mapRef.current=null;};
 },[groups,today,retry]);
 return <section className="customer-map-section" aria-labelledby="customer-map-heading"><div className="map-heading"><div><h2 id="customer-map-heading"><MapPin size={18}/>Customer map</h2><p>{mapped} of {customers.length} customers on the map{missing?` · ${missing} need coordinates`:''}</p></div><Button variant="outline" size="sm" onClick={()=>fitRef.current()} disabled={loading||!!error}><Maximize2 size={15}/>Show all pins</Button></div>
 <div className="map-legend" aria-label="Map pin colours">{(['expired','near','active'] as const).map(s=><span key={s}><i style={{background:colors[s]}}/>{labels[s]} <strong>{counts[s]}</strong></span>)}<small>Near expiry: today or within 2 days</small></div>
 <div className="customer-map-frame"><div ref={container} className="customer-map" role="region" aria-label="Customer locations map. Use arrow keys to pan and plus or minus to zoom."/>{loading&&<div className="map-message" role="status">Loading customer map…</div>}{error&&<div className="map-message" role="alert">{error}<Button variant="outline" onClick={()=>setRetry(n=>n+1)}>Retry map</Button></div>}</div>
 {tilesFailed&&!error&&<p className="map-note" role="status">Some map tiles could not load. Customer pins are still available; check your connection.</p>}
 {!mapped&&<p className="map-note">Add latitude,longitude in a customer’s location details to show their exact pin.</p>}
 {!!missing&&<details className="map-missing"><summary>{missing} customers need coordinates</summary><p>Open a customer’s edit form and add latitude,longitude under More details. Location names alone are not placed on the map.</p><ul>{customers.filter(c=>!groups.some(g=>g.customers.some(x=>x.id===c.id))).map(c=><li key={c.id}>{c.name} · {c.location||'No location'}</li>)}</ul></details>}
 <p className="map-note">Pins include all customers, across all pages. Hover over a pin on desktop, or tap on mobile, for customer details. Customers at the same coordinates share a numbered pin; its colour shows the most urgent status.</p>
 </section>;
}
