import type { Customer } from '../domain';
export function CustomerPhoto({customer}:{customer:Customer}) {
 const n=Array.from(customer.id).reduce((a,c)=>a+c.charCodeAt(0),0);
 const colors=['#cce5f5','#e4d8f2','#d7ebdc','#f3dfcb','#d6e6eb'];
 if(customer.photo)return <img className="avatar customer-photo" src={customer.photo} alt={`${customer.name} profile`} />;
 return <span className="avatar illustrated-avatar" role="img" aria-label={`${customer.name} avatar`} style={{background:colors[n%colors.length]}}><svg viewBox="0 0 48 48" aria-hidden="true"><path d="M5 48c0-15 8-21 19-21s19 6 19 21" fill={['#486a91','#776294','#497861','#997755'][n%4]}/><ellipse cx="24" cy="20" rx="11" ry="13" fill={['#e3ad87','#bc8969','#efc7a7'][n%3]}/><path d="M13 19C10 3 35 1 36 18l-5-6c-6 5-11 3-18 7" fill="#34343d"/><circle cx="20" cy="21" r="1" fill="#34343d"/><circle cx="28" cy="21" r="1" fill="#34343d"/><path d="M21 27q3 2 6 0" fill="none" stroke="#824f42" strokeWidth="1.4" strokeLinecap="round"/></svg></span>;
}
export async function prepareCustomerPhoto(file:File):Promise<string>{
 if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw new Error('Choose a JPG, PNG or WebP photo.');
 if(file.size>10*1024*1024)throw new Error('Choose a photo smaller than 10 MB.');
 const url=URL.createObjectURL(file);
 try { const img=new Image();img.src=url;await img.decode();const canvas=document.createElement('canvas');canvas.width=256;canvas.height=256;const ctx=canvas.getContext('2d');if(!ctx)throw new Error('Photo processing is unavailable.');const size=Math.min(img.width,img.height);ctx.drawImage(img,(img.width-size)/2,(img.height-size)/2,size,size,0,0,256,256);return canvas.toDataURL('image/jpeg',0.78); }
 finally{URL.revokeObjectURL(url);}
}
