import { useEffect, useState, type FormEvent } from "react";
import { CalendarDays, Info, MessageCircle, ChevronDown } from "lucide-react";
import {
  addDays,
  addCalendarMonths,
  displayDate,
  daysLeft,
  todayIST,
  validDate,
  type Customer,
  type Connection,
} from "../domain";
import { CustomerPhoto, prepareCustomerPhoto } from "./CustomerPhoto";
import { parseCoordinates, coordinatesText } from "../location";
import { Button } from "./ui/button";
export function CustomerForm({
  customer,
  saving = false,
  renew = false,
  customers,
  onSave,
  onCancel,
}: {
  customer?: Customer;
  saving?: boolean;
  renew?: boolean;
  customers: Customer[];
  onSave: (c: Customer) => void;
  onCancel: () => void;
}) {
  const [values, setValues] = useState({
    name: customer?.name ?? "",
    mobile: customer?.mobile ?? "",
    alternate: customer?.alternate ?? "",
    location: customer?.location ?? "",
    coordinates: customer ? coordinatesText(customer) : "",
    connection: customer?.connection ?? "JioFiber",
    plan: customer?.plan ?? "",
    amount: String(customer?.amount ?? ""),
    rechargeDate: renew ? todayIST() : (customer?.rechargeDate ?? todayIST()),
    validity: String(customer?.validity ?? 30),
    notes: customer?.notes ?? "",
  });
  const [validityOption, setValidityOption] = useState(
    customer?.validityMonths
      ? `m${customer.validityMonths}`
      : customer
        ? customer.validity === 28
          ? "28"
          : "custom"
        : "m1",
  );
  const [photo, setPhoto] = useState<string | undefined>(customer?.photo);
  const [photoBusy,setPhotoBusy] = useState(false);
  const [photoError,setPhotoError] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [dirty, setDirty] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [demoPreview, setDemoPreview] = useState(false);
  const set = (key: keyof typeof values, value: string) => {
    setDirty(true);
    setValues((v) => ({ ...v, [key]: value }));
    setErrors((e) => ({ ...e, [key]: "" }));
  };
  useEffect(() => {
    if (!dirty) return;
    const handler = (e: BeforeUnloadEvent) => {
      e.preventDefault();
    if (photoBusy || photoError) return;
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [dirty]);
  const months = validityOption.startsWith("m")
    ? Number(validityOption.slice(1))
    : 0;
  const expiry = validDate(values.rechargeDate)
    ? months
      ? addCalendarMonths(values.rechargeDate, months)
      : Number.isInteger(Number(values.validity)) &&
          Number(values.validity) > 0 &&
          Number(values.validity) <= 3650
        ? addDays(values.rechargeDate, Number(values.validity))
        : null
    : null;
  const effectiveDays = expiry ? daysLeft(expiry, values.rechargeDate) : 0;
  const cancel = () => {
    if (!dirty || confirm("Discard unsaved changes?")) onCancel();
  };
  function submit(e: FormEvent) {
    e.preventDefault();
    const er: Record<string, string> = {};
    if (!values.name.trim()) er.name = "Enter the customer’s name.";
    const demoUnchanged = customer?.demo && values.mobile === customer.mobile;
    if (!demoUnchanged && !/^[6-9]\d{9}$/.test(values.mobile))
      er.mobile = "Enter a 10-digit Indian mobile number starting with 6–9.";
    if (
      customers.some((c) => c.id !== customer?.id && c.mobile === values.mobile)
    )
      er.mobile = "This mobile number already belongs to another customer.";
    if (values.alternate && !/^[6-9]\d{9}$/.test(values.alternate))
      er.alternate = "Enter a valid 10-digit Indian mobile number.";

    if (
      values.amount !== "" &&
      (!Number.isFinite(Number(values.amount)) ||
        Number(values.amount) < 0 ||
        Number(values.amount) > 1000000)
    )
      er.amount = "Enter an amount between ₹0 and ₹10,00,000.";
    if (!validDate(values.rechargeDate))
      er.rechargeDate = "Choose a valid recharge date.";
    if (
      !months &&
      (!Number.isInteger(Number(values.validity)) ||
        Number(values.validity) < 1 ||
        Number(values.validity) > 3650)
    )
      er.validity = "Validity must be 1–3,650 whole days.";
    let coordinates: ReturnType<typeof parseCoordinates>;
    try { coordinates = parseCoordinates(values.coordinates); }
    catch(error) { er.coordinates = (error as Error).message; }
    setErrors(er);
    if (er.amount || er.location || er.coordinates) setMoreOpen(true);
    if (Object.keys(er).length) {
      requestAnimationFrame(() =>
        document.querySelector<HTMLElement>('[aria-invalid="true"]')?.focus(),
      );
      return;
    }
    const updated: Customer = {
      id: customer?.id ?? crypto.randomUUID(),
      photo,
      ...values,
      name: values.name.trim(),
      location: values.location.trim(),
      plan: values.plan.trim(),
      connection: values.connection as Connection,
      amount: Number(values.amount || 0),
      validity: effectiveDays,
      validityMonths: months || undefined,
      expiryDate: expiry!,
      coordinateSource: customer?.coordinateSource === "demo" && values.coordinates === coordinatesText(customer) ? "demo" : undefined,
      latitude: coordinates?.latitude,
      longitude: coordinates?.longitude,
      demo: !!customer?.demo && values.mobile === customer.mobile,
      reminders: customer?.reminders ?? [],
      renewals: customer?.renewals ?? [],
    };
    if (renew)
      updated.renewals = [
        ...updated.renewals,
        {
          rechargeDate: updated.rechargeDate,
          validity: updated.validity,
          validityMonths: updated.validityMonths,
          plan: updated.plan,
          amount: updated.amount,
          recordedAt: new Date().toISOString(),
        },
      ];
    onSave(updated);
  }
  const field = (
    key: keyof typeof values,
    label: string,
    props: React.InputHTMLAttributes<HTMLInputElement> = {},
  ) => (
    <div className="field">
      <label htmlFor={key}>{label}</label>
      <input
        id={key}
        name={key}
        value={values[key]}
        onChange={(e) => set(key, e.target.value)}
        aria-invalid={!!errors[key]}
        aria-describedby={errors[key] ? `${key}-error` : undefined}
        {...props}
      />
      {errors[key] ? (
        <span id={`${key}-error`} className="field-error" aria-live="polite">
          {errors[key]}
        </span>
      ) : null}
    </div>
  );
  return (
    <form onSubmit={submit} noValidate>
      <fieldset disabled={saving || photoBusy} className="form-fieldset">
        <div className="dialog-body form-body">
          {!renew ? <div className="photo-editor">
            <CustomerPhoto customer={{ id: customer?.id ?? 'new', name: values.name || 'Customer', photo } as Customer} />
            <div className="field"><label htmlFor="customer-photo">Customer photo (optional)</label>
              <input id="customer-photo" type="file" accept="image/jpeg,image/png,image/webp" onChange={async e=>{const file=e.target.files?.[0];if(!file)return;setPhotoBusy(true);setPhotoError('');try{setPhoto(await prepareCustomerPhoto(file));setDirty(true);}catch(err){setPhotoError((err as Error).message);}finally{setPhotoBusy(false);e.target.value='';}}}/>
              <small>JPG, PNG or WebP. Cropped to a small square.</small>
              {photoError && <span role="alert" className="field-error">{photoError}</span>}
              {photo && <Button type="button" variant="ghost" onClick={()=>{setPhoto(undefined);setPhotoError('');setDirty(true);}}>Remove photo</Button>}
            </div>
          </div> : null}
          {!renew ? (
            <div className="form-grid simple-customer-grid">
              {field("name", "Customer name *", {
                required: true,
                autoComplete: "name",
                maxLength: 100,
                placeholder: "e.g. Aditi Roy",
              })}
              <div className="phone-field-group">
                {field("mobile", "Number *", {
                  required: true,
                  type: "tel",
                  inputMode: "numeric",
                  autoComplete: "tel-national",
                  maxLength: 10,
                  placeholder: "10-digit mobile number",
                })}
                {customer?.demo && values.mobile === customer.mobile ? (
                  <Button
                    type="button"
                    variant="outline"
                    className="whatsapp-contact"
                    onClick={() => setDemoPreview((v) => !v)}
                  >
                    <MessageCircle size={16} />
                    WhatsApp preview
                  </Button>
                ) : /^[6-9]\d{9}$/.test(values.mobile) ? (
                  <Button
                    asChild
                    variant="outline"
                    className="whatsapp-contact"
                  >
                    <a
                      href={`https://wa.me/91${values.mobile}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <MessageCircle size={16} />
                      WhatsApp
                    </a>
                  </Button>
                ) : (
                  <Button
                    type="button"
                    variant="outline"
                    className="whatsapp-contact"
                    disabled
                    title="Enter a valid mobile number to open WhatsApp"
                  >
                    <MessageCircle size={16} />
                    WhatsApp
                  </Button>
                )}
              </div>
              {demoPreview ? (
                <p className="demo-contact-notice">
                  Demo preview: this fictional number cannot open WhatsApp.
                </p>
              ) : null}
              {field("alternate", "Alternate number", {
                type: "tel",
                inputMode: "numeric",
                autoComplete: "off",
                maxLength: 10,
                placeholder: "Optional",
              })}
              {customer ? (
                field("plan", "Plan", {
                  maxLength: 100,
                  placeholder: "e.g. Unlimited 100 Mbps",
                })
              ) : (
                <div className="field">
                  <label htmlFor="plan">Plan</label>
                  <select
                    id="plan"
                    name="plan"
                    value={values.plan}
                    onChange={(e) => set("plan", e.target.value)}
                  >
                    <option value="">Select plan</option>
                    <option value="Unlimited 30 Mbps">30 Mbps</option>
                    <option value="Unlimited 100 Mbps">100 Mbps</option>
                  </select>
                </div>
              )}
            </div>
          ) : (
            <>
              <div className="renew-customer">
                <strong>{customer?.name}</strong>
                <span>
                  {customer?.connection} · Current expiry{" "}
                  {displayDate(customer!.expiryDate)}
                </span>
              </div>
              <div className="form-grid">
                {field("plan", "Plan", {
                  maxLength: 100,
                  placeholder: "e.g. Unlimited 100 Mbps",
                })}
                {field("amount", "Recharge amount (₹)", {
                  type: "number",
                  min: 0,
                  max: 1000000,
                  step: "0.01",
                  placeholder: "e.g. 899",
                })}
              </div>
            </>
          )}
          <div className="form-grid activation-grid">
            {field("rechargeDate", "Activation date", { type: "date" })}
            <div className="field">
              <label htmlFor="validity-option">Validity</label>
              <select
                id="validity-option"
                value={validityOption}
                onChange={(e) => {
                  setValidityOption(e.target.value);
                  if (e.target.value === "28") set("validity", e.target.value);
                }}
              >
                <option value="28">28 days</option>
                {[1, 2, 4, 6, 8, 12].map((n) => (
                  <option key={n} value={`m${n}`}>
                    {n} month{n === 1 ? "" : "s"}
                  </option>
                ))}
                <option value="custom">Custom</option>
              </select>
            </div>
            {validityOption === "custom"
              ? field("validity", "Custom validity (days)", {
                  type: "number",
                  min: 1,
                  max: 3650,
                  step: 1,
                })
              : null}
          </div>
          <div className="expiry-preview simple-expiry">
            <CalendarDays size={20} />
            <div>
              <span>Expiry date</span>
              <strong>
                {expiry ? displayDate(expiry) : "Choose a date and validity"}
              </strong>
            </div>
            <div className="remaining-preview">
              <span>Days remaining</span>
              <strong>
                {expiry
                  ? daysLeft(expiry) < 0
                    ? `${Math.abs(daysLeft(expiry))} days overdue`
                    : daysLeft(expiry) === 0
                      ? "Expires today"
                      : `${daysLeft(expiry)} days`
                  : "—"}
              </strong>
            </div>
          </div>
          {!renew ? (
            <div className="optional-details">
              <button
                type="button"
                className="optional-toggle"
                aria-expanded={moreOpen}
                aria-controls="optional-customer-fields"
                onClick={() => setMoreOpen((v) => !v)}
              >
                <span>
                  More details <small>Connection, area, amount & notes</small>
                </span>
                <ChevronDown size={18} className={moreOpen ? "expanded" : ""} />
              </button>
              {moreOpen ? (
                <div id="optional-customer-fields" className="optional-fields">
                  <div className="form-grid">
                    <div className="field">
                      <label htmlFor="connection">Connection type</label>
                      <select
                        id="connection"
                        value={values.connection}
                        onChange={(e) => set("connection", e.target.value)}
                      >
                        <option>JioFiber</option>
                        <option>Jio AirFiber</option>
                      </select>
                    </div>
                    {field("location", "Location / area", {
                      autoComplete: "address-level2",
                      maxLength: 100,
                      placeholder: "e.g. New Town",
                    })}
                    {field("coordinates", "Latitude, longitude", {
                      type: "text", maxLength: 64,
                      placeholder: "22.736390,88.373882",
                      autoComplete: "off",
                    })}
                    {field("amount", "Recharge amount (₹)", {
                      type: "number",
                      min: 0,
                      max: 1000000,
                      step: "0.01",
                      placeholder: "Optional",
                    })}
                  </div>
                  <div className="field">
                    <label htmlFor="notes">Notes</label>
                    <textarea
                      id="notes"
                      name="notes"
                      value={values.notes}
                      onChange={(e) => set("notes", e.target.value)}
                      rows={2}
                      maxLength={2000}
                      placeholder="Optional customer notes…"
                    />
                  </div>
                </div>
              ) : null}
            </div>
          ) : null}
          {customer?.demo ? (
            <p className="form-hint">
              <Info size={16} />
              This is a fictional demo customer. Replace its phone number with a real customer number to enable WhatsApp.
            </p>
          ) : null}
        </div>
        <footer className="dialog-footer">
          <Button type="button" variant="outline" onClick={cancel}>
            Cancel
          </Button>
          <Button type="submit" disabled={saving || photoBusy || !!photoError}>
            {saving
              ? "Saving…"
              : renew
                ? "Renew recharge"
                : customer
                  ? "Save changes"
                  : "Add customer"}
          </Button>
        </footer>
      </fieldset>
    </form>
  );
}
