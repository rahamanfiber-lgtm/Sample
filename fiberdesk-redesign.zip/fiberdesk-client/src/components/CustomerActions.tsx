import * as DropdownMenu from "@radix-ui/react-dropdown-menu";
import {
  MoreHorizontal,
  Eye,
  Pencil,
  Trash2,
  RefreshCw,
  MessageCircle,
} from "lucide-react";
import { whatsappUrl, type Customer } from "../domain";
import { Button } from "./ui/button";
export type Action = "view" | "edit" | "delete" | "renew" | "message";
export function CustomerActions({
  customer,
  onAction,
}: {
  customer: Customer;
  onAction: (action: Action, c: Customer) => void;
}) {
  return (
    <div className="row-actions">
      {whatsappUrl(customer) ? (
        <Button asChild size="icon" variant="ghost" className="whatsapp-action">
          <a href={whatsappUrl(customer)!} aria-label={`WhatsApp for ${customer.name}`} title="Open WhatsApp">
            <MessageCircle size={18} />
          </a>
        </Button>
      ) : (
        <Button size="icon" variant="ghost" className="whatsapp-action"
          aria-label={`WhatsApp preview for ${customer.name}`} title="Demo WhatsApp preview"
          onClick={() => onAction("message", customer)}>
          <MessageCircle size={18} />
        </Button>
      )}
      <Button
        size="icon"
        variant="ghost"
        aria-label={`Renew recharge for ${customer.name}`}
        title="Renew recharge"
        onClick={() => onAction("renew", customer)}
      >
        <RefreshCw size={17} />
      </Button>
      <DropdownMenu.Root>
        <DropdownMenu.Trigger asChild>
          <Button
            size="icon"
            variant="ghost"
            aria-label={`More actions for ${customer.name}`}
          >
            <MoreHorizontal size={20} />
          </Button>
        </DropdownMenu.Trigger>
        <DropdownMenu.Portal>
          <DropdownMenu.Content className="dropdown" align="end" sideOffset={6}>
            {(
              [
                ["view", Eye, "View customer"],
                ["edit", Pencil, "Edit customer"],
                ["delete", Trash2, "Delete customer"],
              ] as const
            ).map(([action, Icon, label]) => (
              <DropdownMenu.Item
                key={action}
                className={`dropdown-item ${action === "delete" ? "danger-text" : ""}`}
                onSelect={() => onAction(action, customer)}
              >
                <Icon size={16} />
                {label}
              </DropdownMenu.Item>
            ))}
          </DropdownMenu.Content>
        </DropdownMenu.Portal>
      </DropdownMenu.Root>
    </div>
  );
}
