import { useEffect, useState, lazy, Suspense, type FormEvent } from "react";
import {
  Wifi,
  Mail,
  ShieldCheck,
  RefreshCw,
  LogOut,
  Cloud,
  TriangleAlert,
  LogIn,
  CalendarDays,
  Users,
  MessageCircle,
} from "lucide-react";
import type { Session } from "@supabase/supabase-js";
import {
  supabase,
  OPERATOR_EMAIL,
  resolveLoginEmail,
  loadWorkspace,
  saveWorkspace,
  type CloudSnapshot,
} from "../lib/supabase";

import { Button } from "./ui/button";
const App = lazy(() => import("../App"));

export default function CloudGate() {
  const [session, setSession] = useState<Session | null>(null),
    [authReady, setAuthReady] = useState(false),
    [snapshot, setSnapshot] = useState<CloudSnapshot | null>(null),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(false),
    [email, setEmail] = useState(OPERATOR_EMAIL),
    [password, setPassword] = useState(""),
    [emailMode, setEmailMode] = useState(false),
    [sent, setSent] = useState(false),
    [sending, setSending] = useState(false);
  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(({ data, error }) => {
      if (!active) return;
      if (error)
        setError(
          "Your sign-in session could not be read. Please sign in again.",
        );
      setSession(data.session);
      setAuthReady(true);
    });
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next);
      setAuthReady(true);
      if (!next) setSnapshot(null);
    });
    return () => {
      active = false;
      subscription.unsubscribe();
    };
  }, []);
  const authorized =
    !!session?.user.email &&
    session.user.email.toLowerCase() === OPERATOR_EMAIL;
  async function load() {
    setLoading(true);
    setError("");
    try {
      let cloud = await loadWorkspace();
      if (!cloud.initialized) {
        const local = { customers: [] };
        try {
          const revision = await saveWorkspace(0, local.customers);
          cloud = { initialized: true, revision, customers: local.customers };
        } catch {
          cloud = await loadWorkspace();
          if (!cloud.initialized)
            throw new Error(
              "The cloud workspace could not be created. Your browser data is still safe. Try again.",
            );
        }
      }
      setSnapshot(cloud);
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "Could not load customers. Try again.",
      );
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    if (authorized) void load();
  }, [session?.user.id, authorized]);
  async function send(e: FormEvent) {
    e.preventDefault();
    setError("");
    if (!resolveLoginEmail(email)) {
      setError("Use your operator username or email to access FiberDesk.");
      return;
    }
    setSending(true);
    try {
      if (!emailMode) {
        const { error } = await supabase.auth.signInWithPassword({
          email: OPERATOR_EMAIL,
          password,
        });
        if (error) throw error;
        setPassword("");
        return;
      }
      const { error } = await supabase.auth.signInWithOtp({
        email: OPERATOR_EMAIL,
        options: {
          emailRedirectTo: window.location.origin + "/",
          shouldCreateUser: true,
        },
      });
      if (error) throw error;
      setSent(true);
    } catch (e) {
      const message =
        e instanceof Error ? e.message : "Sign-in failed. Please try again.";
      setError(
        message.toLowerCase().includes("email not confirmed")
          ? "Confirm the Supabase email in your inbox, then sign in again."
          : message.toLowerCase().includes("invalid login credentials")
            ? "Username or password isn’t correct. Try again."
            : message,
      );
    } finally {
      setSending(false);
    }
  }
  async function signOut() {
    const { error } = await supabase.auth.signOut({ scope: "local" });
    if (error) throw new Error("Could not sign out. Please try again.");
  }
  if (snapshot && authorized)
    return (
      <Suspense
        fallback={
          <main className="auth-page">
            <p>Opening your customer workspace…</p>
          </main>
        }
      >
        <App
          key={session!.user.id}
          initialSnapshot={snapshot}
          onSignOut={signOut}
          operatorEmail={OPERATOR_EMAIL}
        />
      </Suspense>
    );
  return (
    <main className="auth-page">
      <a className="brand auth-brand" href="/">
        <span className="brand-mark">
          <Wifi size={25} />
        </span>
        <span>FiberDesk</span>
      </a>
      <div className="auth-layout">
        <section className="auth-story" aria-label="About FiberDesk">
          <span className="auth-story-kicker"><span /> OPERATOR WORKSPACE</span>
          <h1>Every connection, <em>in good hands.</em></h1>
          <p className="auth-story-copy">
            A calmer way to manage your JioFiber and AirFiber customers, recharge dates and daily follow-ups.
          </p>
          <div className="auth-story-features">
            <div><span className="auth-feature-icon"><Users size={18} /></span><span><strong>Customer records</strong><small>Find the right customer in seconds</small></span></div>
            <div><span className="auth-feature-icon"><CalendarDays size={18} /></span><span><strong>Recharge tracking</strong><small>See what expires next, at a glance</small></span></div>
            <div><span className="auth-feature-icon"><MessageCircle size={18} /></span><span><strong>Simple follow-ups</strong><small>Keep reminders personal and in your control</small></span></div>
          </div>
          <div className="auth-story-foot"><ShieldCheck size={16} /> Private operator access · Cloud-synced workspace</div>
        </section>
        <section className="auth-card" aria-busy={loading || sending}>
        <span className="auth-symbol">
          {authorized ? <Cloud size={25} /> : <ShieldCheck size={25} />}
        </span>
        <h1>
          {!authReady
            ? "Opening your workspace…"
            : authorized
              ? "Your cloud workspace"
              : sent
                ? "Check your email"
                : "Sign in to FiberDesk"}
        </h1>
        <p>
          {!authReady
            ? "Checking your secure sign-in."
            : authorized
              ? "Customer records, renewals and reminders stay in sync across your devices."
              : sent
                ? `We sent a sign-in link to ${OPERATOR_EMAIL}. Open it to continue.`
                : "Sign in to manage your customers and recharges from any device."}
        </p>
        {error ? (
          <div className="auth-error" role="alert">
            <TriangleAlert size={17} />
            <span>{error}</span>
          </div>
        ) : null}
        {authReady && authorized ? (
          <Button disabled={loading} onClick={load}>
            <RefreshCw size={17} className={loading ? "is-spinning" : ""} />
            {loading ? "Loading customers…" : "Try again"}
          </Button>
        ) : authReady && session ? (
          <>
            <p className="auth-error">
              This account does not have access to FiberDesk.
            </p>
            <Button variant="outline" onClick={signOut}>
              <LogOut size={16} />
              Use another account
            </Button>
          </>
        ) : authReady ? (
          <form onSubmit={send}>
            <div className="field">
              <label htmlFor="operator-email">
                {emailMode ? "Operator email" : "Username or email"}
              </label>
              <input
                id="operator-email"
                type="text"
                autoComplete="username"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  setError("");
                }}
                required
                disabled={sending}
              />
            </div>
            {!emailMode ? (
              <div className="field auth-password">
                <label htmlFor="operator-password">Password</label>
                <input
                  id="operator-password"
                  type="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError("");
                  }}
                  required
                  disabled={sending}
                />
              </div>
            ) : null}
            <Button type="submit" disabled={sending || sent}>
              {emailMode ? <Mail size={17} /> : <LogIn size={17} />}
              {sending
                ? emailMode
                  ? "Sending link…"
                  : "Signing in…"
                : !emailMode
                  ? "Sign in"
                  : sent
                    ? "Sign-in link sent"
                    : "Send sign-in link"}
            </Button>
            <button
              type="button"
              className="auth-resend text-button"
              disabled={sending}
              onClick={() => {
                setEmailMode((v) => !v);
                setEmail(emailMode ? "test" : OPERATOR_EMAIL);
                setSent(false);
                setError("");
                setPassword("");
              }}
            >
              {emailMode
                ? "Use username & password"
                : "Use an email sign-in link instead"}
            </button>
            {sent ? (
              <button
                type="button"
                className="auth-resend text-button"
                onClick={() => setSent(false)}
              >
                Use a different email or resend
              </button>
            ) : null}
          </form>
        ) : null}
        <div className="auth-footnote">
          <ShieldCheck size={15} />
          Only your operator account can access customer data.
        </div>
        </section>
      </div>
      <p className="auth-local-note">
        Your customer records are stored securely in your cloud workspace.
      </p>
    </main>
  );
}
