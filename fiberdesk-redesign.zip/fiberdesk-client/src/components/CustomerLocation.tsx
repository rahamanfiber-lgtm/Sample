import { MapPin } from 'lucide-react';
import type { Customer } from '../domain';
import { googleMapsUrl } from '../location';
export function CustomerLocation({customer}:{customer:Customer}){
 const href=googleMapsUrl(customer);
 return <span className="customer-location">{href?<a className="map-link" href={href} target="_blank" rel="noopener noreferrer" aria-label={`Open ${customer.name} location in Google Maps`} title="Open location in Google Maps in a new tab"><MapPin size={16}/><span>{customer.location||'View location'}</span></a>:<><MapPin size={16} aria-hidden="true"/><span>{customer.location||'No location'}</span></>}</span>;
}
