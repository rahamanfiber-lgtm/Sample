import ExcelJS from 'exceljs';
import { bulkTemplate, parseRows } from './bulk';
import { todayIST } from './domain';

export async function createExcelTemplate(): Promise<Uint8Array> {
 const workbook=new ExcelJS.Workbook();
 const sheet=workbook.addWorksheet('Customers',{views:[{state:'frozen',ySplit:1}]});
 const rows=parseRows(bulkTemplate); rows[1][4]=todayIST(); sheet.addRows(rows);
 sheet.columns.forEach((column,i)=>{column.width=[25,20,22,20,22,20,25,18,18][i];});
 sheet.getRow(1).height=28;
 sheet.getRow(1).eachCell(cell=>{cell.font={bold:true,color:{argb:'FFFFFFFF'}};cell.fill={type:'pattern',pattern:'solid',fgColor:{argb:'FF175CD3'}};cell.alignment={vertical:'middle'};});
 sheet.autoFilter='A1:H501';
 sheet.getColumn(2).numFmt='@';sheet.getColumn(3).numFmt='@';sheet.getColumn(5).numFmt='yyyy-mm-dd';
 for(let row=2;row<=501;row++){
  sheet.getCell(`D${row}`).dataValidation={type:'list',allowBlank:true,formulae:['"30 Mbps,100 Mbps"'],showErrorMessage:true,error:'Choose 30 Mbps or 100 Mbps.'};
  sheet.getCell(`F${row}`).dataValidation={type:'list',allowBlank:true,formulae:['"28 days,1 month,2 months,4 months,6 months,8 months,12 months"'],showErrorMessage:true,error:'Choose a validity from the list.'};
 }
 const help=workbook.addWorksheet('Instructions');
 help.columns=[{width:105}];
 help.addRows([['FiberDesk bulk entry'],['1. Fill the Customers sheet. Replace or delete the example row.'],['2. Name and Number are required. Use 10-digit Indian mobile numbers.'],['3. Choose Plan and Validity from their dropdowns. Activation Date: YYYY-MM-DD or an Excel date.'],['4. Leave optional fields blank. Import up to 500 customers per file.'],['5. Save as .xlsx, upload in FiberDesk and review the preview before importing.'],['Coordinates: latitude,longitude — for example 22.736390,88.373882.'],['Do not use formulas. Only the Customers sheet is imported.']]);
 help.getCell('A1').font={bold:true,size:16,color:{argb:'FF175CD3'}};
 return new Uint8Array(await workbook.xlsx.writeBuffer());
}

export async function excelToCsv(data:ArrayBuffer):Promise<string>{
 const workbook=new ExcelJS.Workbook();
 try{await workbook.xlsx.load(data);}catch{throw new Error('Could not read this workbook. Save it as an Excel .xlsx file and try again.');}
 const sheet=workbook.getWorksheet('Customers')??workbook.worksheets.find(s=>s.state==='visible');
 if(!sheet)throw new Error('The workbook has no visible customer worksheet.');
 const rows:string[][]=[];
 sheet.eachRow({includeEmpty:false},row=>{
  const values:string[]=[];
  if(row.cellCount>32)throw new Error('Use the Excel template with up to 32 columns.');
  for(let i=1;i<=Math.max(row.cellCount,9);i++){
   const cell=row.getCell(i), v=cell.value;
   if(cell.type===ExcelJS.ValueType.Formula)throw new Error(`Cell ${cell.address} contains a formula. Paste its value before importing.`);
   if(v instanceof Date)values.push(v.toISOString().slice(0,10));
   else if(v===null||v===undefined)values.push('');
   else values.push(cell.text.trim());
  }
  if(values.some(Boolean))rows.push(values);
  if(rows.length>501)throw new Error('Import up to 500 customers at a time.');
 });
 if(rows.length<2)throw new Error('Add at least one customer below the header row.');
 return rows.map(row=>row.map(v=>'"'+v.replaceAll('"','""')+'"').join(',')).join('\n');
}
