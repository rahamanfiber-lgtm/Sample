import {describe,it,expect} from 'vitest';
import ExcelJS from 'exceljs';
import {createExcelTemplate,excelToCsv} from './excel';
import {previewBulk} from './bulk';
describe('Excel bulk entry',()=>{
 it('round-trips the template without importing its instructions or formatted blank rows',async()=>{const bytes=await createExcelTemplate();const text=await excelToCsv(bytes.buffer as ArrayBuffer);const rows=previewBulk(text,[]);expect(rows).toHaveLength(1);expect(rows[0].errors).toEqual([]);expect(rows[0].customer.plan).toBe('Unlimited 30 Mbps');});
 it('reads dates and numeric phone values from an Excel worksheet',async()=>{const book=new ExcelJS.Workbook();const sheet=book.addWorksheet('Sheet1');sheet.addRow(['Name','Number','Activation Date','Validity']);sheet.addRow(['Customer',9876543210,new Date('2026-01-31T00:00:00Z'),'1 month']);sheet.getCell('C2').numFmt='yyyy-mm-dd';const buffer=await book.xlsx.writeBuffer();const rows=previewBulk(await excelToCsv(buffer),[]);expect(rows[0].errors).toEqual([]);expect(rows[0].customer.expiryDate).toBe('2026-02-28');});
 it('rejects formulas and invalid workbooks with clear errors',async()=>{const book=new ExcelJS.Workbook();const sheet=book.addWorksheet('Customers');sheet.addRow(['Name','Number']);sheet.addRow(['Customer',{formula:'1+1',result:2}]);await expect(excelToCsv(await book.xlsx.writeBuffer())).rejects.toThrow('formula');await expect(excelToCsv(new ArrayBuffer(4))).rejects.toThrow('Could not read');});
});
