import type { Customer } from './domain';
export function parseCoordinates(value: string): {latitude:number;longitude:number}|undefined {
 if(!value.trim())return undefined;
 const parts=value.trim().split(',').map(v=>v.trim());
 if(parts.length!==2||parts.some(v=>!/^[-+]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(v)))throw new Error('Enter latitude,longitude — for example 22.736390,88.373882.');
 const [latitude,longitude]=parts.map(Number);
 if(!Number.isFinite(latitude)||Math.abs(latitude)>90||!Number.isFinite(longitude)||Math.abs(longitude)>180)throw new Error('Latitude must be −90 to 90 and longitude −180 to 180.');
 return {latitude,longitude};
}
export function coordinatesText(c: Pick<Customer,'latitude'|'longitude'>){
 return c.latitude===undefined&&c.longitude===undefined?'':`${c.latitude??''},${c.longitude??''}`;
}
export function googleMapsUrl(c:Pick<Customer,'latitude'|'longitude'> & {location?:string}){
 const exact=c.latitude!==undefined&&c.longitude!==undefined&&Number.isFinite(c.latitude)&&Number.isFinite(c.longitude)&&Math.abs(c.latitude)<=90&&Math.abs(c.longitude)<=180;
 const query=exact?`${c.latitude},${c.longitude}`:c.location?.trim();
 return query?`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`:null;
}
