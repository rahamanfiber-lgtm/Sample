import { format, parseISO } from "date-fns";
export type Connection = "JioFiber" | "Jio AirFiber";
export type Filter = "All" | "Expired" | "Today" | "Next 2 Days" | "Active";
export interface Reminder {
  sentAt: string;
}
export interface Renewal {
  rechargeDate: string;
  validity: number;
  validityMonths?: number;
  plan: string;
  amount: number;
  recordedAt: string;
}
export interface Customer {
  id: string;
  name: string;
  mobile: string;
  alternate: string;
  location: string;
  photo?: string;
  coordinateSource?: "demo";
  latitude?: number;
  longitude?: number;
  connection: Connection;
  plan: string;
  amount: number;
  rechargeDate: string;
  validity: number;
  validityMonths?: number;
  expiryDate: string;
  notes: string;
  reminders: Reminder[];
  renewals: Renewal[];
  demo: boolean;
}
export const STORAGE_KEY = "fiberdesk.customers.v1";
export const todayIST = (now = new Date()) =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Kolkata",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(now);
// Date-only values use UTC day arithmetic. Browser timezone and DST never enter the calculation.
export function addDays(date: string, days: number) {
  const d = new Date(`${date}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}
// Calendar-month plans clamp to the last valid day (31 Jan + 1 month = 28/29 Feb).
export function addCalendarMonths(date: string, months: number) {
  const d = new Date(`${date}T00:00:00Z`),
    day = d.getUTCDate();
  d.setUTCDate(1);
  d.setUTCMonth(d.getUTCMonth() + months);
  const last = new Date(
    Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0),
  ).getUTCDate();
  d.setUTCDate(Math.min(day, last));
  return d.toISOString().slice(0, 10);
}
export const validityLabel = (c: {
  validity: number;
  validityMonths?: number;
}) =>
  c.validityMonths
    ? `${c.validityMonths} month${c.validityMonths === 1 ? "" : "s"}`
    : `${c.validity} days`;
export const daysLeft = (expiry: string, today = todayIST()) =>
  Math.round(
    (Date.parse(`${expiry}T00:00:00Z`) - Date.parse(`${today}T00:00:00Z`)) /
      86400000,
  );
export const displayDate = (date: string) =>
  format(parseISO(date), "dd MMM yyyy");
export const rupees = (value: number) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 2,
  }).format(value);
export function status(days: number) {
  return days < 0
    ? { label: "Expired", tone: "red" }
    : days === 0
      ? { label: "Expires today", tone: "amber" }
      : days <= 2
        ? { label: `${days} day${days === 1 ? "" : "s"} left`, tone: "amber" }
        : { label: "Active", tone: "green" };
}
export function matches(c: Customer, filter: Filter, today: string) {
  const d = daysLeft(c.expiryDate, today);
  return (
    filter === "All" ||
    (filter === "Expired" && d < 0) ||
    (filter === "Today" && d === 0) ||
    (filter === "Next 2 Days" && d >= 1 && d <= 2) ||
    (filter === "Active" && d > 2)
  );
}
export function seedCustomers(today = todayIST()): Customer[] {
  const entries: [string, string, Connection, number][] = [
    ["Arjun Saha", "Barasat", "JioFiber", -5],
    ["Riya Das", "Madhyamgram", "Jio AirFiber", -1],
    ["Suman Dutta", "Habra", "JioFiber", 0],
    ["Priya Mondal", "Bongaon", "Jio AirFiber", 1],
    ["Rahul Ghosh", "Dum Dum", "JioFiber", 2],
    ["Ananya Roy", "Barrackpore", "Jio AirFiber", 5],
    ["Debashis Pal", "New Town", "JioFiber", 7],
    ["Mita Sen", "Salt Lake", "JioFiber", 12],
    ["Sayan Biswas", "Kalyani", "Jio AirFiber", 20],
    ["Moumita Sarkar", "Sodepur", "JioFiber", 30],
  ];
  return entries.map(([name, location, connection, offset], i) => {
    const validity = i % 3 === 0 ? 84 : 30;
    const expiryDate = addDays(today, offset);
    return {
      id: `demo-${i + 1}`,
      name,
      location,
      connection,
      mobile: `00000000${String(i + 1).padStart(2, "0")}`,
      alternate: "",
      plan: i % 2 === 0 ? "Unlimited 100 Mbps" : "Unlimited 30 Mbps",
      amount: i % 2 === 0 ? 899 : 599,
      rechargeDate: addDays(expiryDate, -validity),
      validity,
      expiryDate,
      notes:
        "Fictional demonstration customer. Replace with your own customers.",
      reminders: [],
      renewals: [],
      demo: true,
    };
  });
}
export function isCustomer(v: unknown): v is Customer {
  if (!v || typeof v !== "object") return false;
  const c = v as Customer;
  return (
    typeof c.id === "string" &&
    typeof c.name === "string" &&
    typeof c.mobile === "string" &&
    typeof c.alternate === "string" &&
    typeof c.location === "string" &&
    (c.photo === undefined || (typeof c.photo === "string" && c.photo.length <= 200000 && /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(c.photo))) &&
    (c.coordinateSource === undefined || c.coordinateSource === "demo") &&
    (c.latitude === undefined || (Number.isFinite(c.latitude) && Math.abs(c.latitude) <= 90)) &&
    (c.longitude === undefined || (Number.isFinite(c.longitude) && Math.abs(c.longitude) <= 180)) &&
    ["JioFiber", "Jio AirFiber"].includes(c.connection) &&
    typeof c.plan === "string" &&
    Number.isFinite(c.amount) &&
    c.amount >= 0 &&
    Number.isInteger(c.validity) &&
    c.validity > 0 &&
    c.validity <= 3650 &&
    (c.validityMonths === undefined ||
      [1, 2, 4, 6, 8, 12].includes(c.validityMonths)) &&
    validDate(c.rechargeDate) &&
    validDate(c.expiryDate) &&
    typeof c.notes === "string" &&
    Array.isArray(c.reminders) &&
    c.reminders.every(
      (r) =>
        r !== null &&
        typeof r === "object" &&
        typeof r.sentAt === "string" &&
        Number.isFinite(Date.parse(r.sentAt)),
    ) &&
    Array.isArray(c.renewals) &&
    c.renewals.every(
      (r) =>
        r !== null &&
        typeof r === "object" &&
        (r.validityMonths === undefined ||
          [1, 2, 4, 6, 8, 12].includes(r.validityMonths)) &&
        validDate(r.rechargeDate) &&
        Number.isInteger(r.validity) &&
        r.validity > 0 &&
        r.validity <= 3650 &&
        typeof r.plan === "string" &&
        Number.isFinite(r.amount) &&
        r.amount >= 0 &&
        typeof r.recordedAt === "string" &&
        Number.isFinite(Date.parse(r.recordedAt)),
    ) &&
    typeof c.demo === "boolean"
  );
}
export function validDate(value: string) {
  return (
    typeof value === "string" &&
    /^\d{4}-\d{2}-\d{2}$/.test(value) &&
    Number.isFinite(Date.parse(value)) &&
    new Date(`${value}T00:00:00Z`).toISOString().slice(0, 10) === value
  );
}
export function readCustomers(): {
  customers: Customer[];
  error: string | null;
} {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw === null) return { customers: seedCustomers(), error: null };
    const data = JSON.parse(raw);
    if (
      data.version !== 1 ||
      !Array.isArray(data.customers) ||
      !data.customers.every(isCustomer)
    )
      throw new Error("Invalid data");
    return { customers: data.customers, error: null };
  } catch {
    return {
      customers: [],
      error:
        "Saved data could not be read. Your existing storage has been preserved. Export a backup or check browser storage before continuing.",
    };
  }
}
export function csv(customers: Customer[]) {
  const escape = (s: unknown) => {
    let v = String(s ?? "");
    if (/^[=+\-@\t\r]/.test(v)) v = "'" + v;
    return '"' + v.replaceAll('"', '""') + '"';
  };
  const headers = [
    "Customer Name",
    "Mobile",
    "Alternate Mobile",
    "Location",
    "Latitude",
    "Longitude",
    "Connection Type",
    "Plan",
    "Amount INR",
    "Activation Date",
    "Validity",
    "Validity Days",
    "Expiry Date",
    "Notes",
    "Last Reminder",
    "Demo",
  ];
  return (
    "\uFEFF" +
    [
      headers,
      ...customers.map((c) => [
        c.name,
        c.mobile,
        c.alternate,
        c.location,
        c.latitude,
        c.longitude,
        c.connection,
        c.plan,
        c.amount,
        c.rechargeDate,
        validityLabel(c),
        c.validity,
        c.expiryDate,
        c.notes,
        c.reminders.at(-1)?.sentAt || "",
        c.demo ? "Yes" : "No",
      ]),
    ]
      .map((r) => r.map(escape).join(","))
      .join("\r\n")
  );
}

export function reminderMessage(c: Customer, today = todayIST()) {
  const expired = daysLeft(c.expiryDate, today) < 0;
  return `Hello ${c.name},\n\nYour ${c.connection} plan ${c.plan || "(current plan)"} ${expired ? "expired" : "will expire"} on ${displayDate(c.expiryDate)}.\n\nPlease recharge your connection to ${expired ? "restore or continue service" : "continue uninterrupted service"}.\n\nThank you!`;
}
export function whatsappUrl(c: Customer, today = todayIST()) {
  if (c.demo || !/^[6-9]\d{9}$/.test(c.mobile)) return null;
  return `https://wa.me/91${c.mobile}?text=${encodeURIComponent(reminderMessage(c, today))}`;
}
