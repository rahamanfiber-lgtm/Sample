import {describe,it,expect} from 'vitest';
import {previewBulk,parseRows} from './bulk';
import {isCustomer,seedCustomers} from './domain';
describe('bulk customer entry',()=>{
 it('parses quoted CSV and spreadsheet tabs',()=>{expect(parseRows('Name,Number,Location\r\n"Roy, A",9876543210,"New\nTown"')).toEqual([['Name','Number','Location'],['Roy, A','9876543210','New\nTown']]);expect(parseRows('Name\tNumber\nA\t9876543210')[1]).toEqual(['A','9876543210']);});
 it('creates valid customer records with month-end expiry and coordinates',()=>{const rows=previewBulk('Name,Number,Plan,Activation Date,Validity,Latitude,Longitude\nA,+919876543210,100 Mbps,2026-01-31,1 month,0,88',[]);expect(rows[0].errors).toEqual([]);expect(isCustomer(rows[0].customer)).toBe(true);expect(rows[0].customer.expiryDate).toBe('2026-02-28');expect(rows[0].customer.latitude).toBe(0);});
 it('blocks duplicates inside an import and against saved customers',()=>{const existing={...seedCustomers()[0],mobile:'9876543210'};const rows=previewBulk('Name,Number\nA,9876543210\nB,9876543210',[existing]);expect(rows.every(r=>r.errors.includes('Duplicate number'))).toBe(true);});
 it('reports invalid rows without preparing them for save',()=>{const rows=previewBulk('Name,Number,Activation Date,Validity,Latitude\n,123,2026-02-30,3 months,100',[]);expect(rows[0].errors.length).toBeGreaterThanOrEqual(4);expect(()=>previewBulk('Foo,Bar\nA,B',[])).toThrow('header');expect(()=>parseRows('"A')).toThrow('closing quote');});
});
