import {daysLeft,type Customer} from './domain';
export type MapStatus='expired'|'near'|'active';
export function customerMapStatus(c:Customer,today:string):MapStatus{const days=daysLeft(c.expiryDate,today);return days<0?'expired':days<=2?'near':'active';}
export function hasMapCoordinates(c:Customer):c is Customer & {latitude:number;longitude:number}{return typeof c.latitude==='number'&&typeof c.longitude==='number'&&Number.isFinite(c.latitude)&&Number.isFinite(c.longitude)&&Math.abs(c.latitude)<=90&&Math.abs(c.longitude)<=180;}
export function mapGroups(customers:Customer[]){const groups=new Map<string,{latitude:number;longitude:number;customers:Customer[]}>();for(const c of customers){if(!hasMapCoordinates(c))continue;const key=`${c.latitude},${c.longitude}`;const group=groups.get(key)??{latitude:c.latitude,longitude:c.longitude,customers:[]};group.customers.push(c);groups.set(key,group);}return [...groups.values()];}
