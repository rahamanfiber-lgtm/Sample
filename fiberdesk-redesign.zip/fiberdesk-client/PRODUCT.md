# FiberDesk
<!-- impeccable:product-schema 1 -->
## Platform
web
## Stack
React, TypeScript, Vite, Tailwind CSS, shadcn/ui patterns with Radix primitives, Lucide, date-fns. Explicitly requested in the supplied brief.
## Users
A local JioFiber and Jio AirFiber operator managing customer recharges on desktop and mobile.
## Product Purpose
Find customers, identify expired or upcoming recharges, keep a manual reminder checklist, and renew plans in minimal clicks.
## Capabilities and Constraints
Local-only versioned browser storage; no backend, authentication, paid services, or automatic messaging. Exactly ten clearly marked fictional customers seeded once. User subsequently requested WhatsApp buttons again: allow manual WhatsApp links for real valid numbers, demo preview only. Simplified entry shows activation date, name, number, alternate number, plan, validity, and days remaining; only name/number required. Other fields are optional. Calendar calculations use Asia/Kolkata. User explicitly specified all required workflows and visual constraints; no additional product assumptions are required.
## Brand Commitments
FiberDesk. Friendly, precise operator language. Blue #175CD3, ground #F8FAFC, ink #101828, white surfaces, Inter, compact 12–16px cards.
## Accessibility & Inclusion
Keyboard-accessible controls, visible focus, inline validation, touch-friendly mobile cards, reduced motion, text labels on statuses.

## Latest scope
Mobile-first only: use the compact customer-card interface at all widths; no separate desktop table. Validity choices are 28 days and 1, 2, 4, 6, 8, 12 calendar months. Preserve existing records and custom-day validities.

## Cloud database update
Use Supabase project cfvpxbjhqainirungxtw for customer records, recharge history and reminders. Operator sign-in is restricted to mampi1234.proy@gmail.com, as explicitly supplied by the user. The public app has a sign-in screen; database RLS enforces access. Browser data is retained as a migration backup. Existing backend-free constraints are superseded by this request. No automatic WhatsApp messaging.

The user requested username/password access and selected test / 123456 as the test login. Username test maps to the authorized operator email; Supabase validates the password. Email confirmation and sign-in link fallback remain enabled.
