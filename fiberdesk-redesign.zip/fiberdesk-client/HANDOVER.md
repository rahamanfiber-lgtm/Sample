# FiberDesk — Client handover

Live app: https://fiberdesk-nu.vercel.app/
Vercel project: https://vercel.com/air-6c87/fiberdesk
Supabase project: https://supabase.com/dashboard/project/oicmrgsvanrrjjsphaxl
Operator email: rahaman.fiber@gmail.com

## Source code
React, TypeScript, Vite. Source is in src/, static assets in public/.
package.json and package-lock.json specify dependencies. vercel.json contains deployment and SPA routing settings.

## Run locally
Install Node.js 24, then run:

```sh
npm ci
cp .env.example .env.local
npm run dev
```

Fill .env.local with VITE_SUPABASE_URL, VITE_SUPABASE_PUBLISHABLE_KEY and VITE_OPERATOR_EMAIL. Use the client project URL and its browser-safe publishable key from Supabase Settings → API Keys. Never use a secret or service-role key in a VITE_ variable.

## Verify and build

```sh
npm test
npm run build
```

The production output is dist/. The dashboard map uses Leaflet and OpenStreetMap tiles with attribution. Excel import is loaded on demand.

## Deployment and ownership
The live app is deployed in the client's Air Vercel workspace (air-6c87) and uses the client's Supabase project oicmrgsvanrrjjsphaxl. Configure the three VITE_ environment variables in Vercel before building from source. Keep the live app URL in Supabase Authentication → URL Configuration.

Customer records are stored in Supabase, not in this source ZIP. The database schema and rollback-only verification script are in supabase/. The schema has already been applied to the client's project; do not run schema.sql blindly against the existing database. Plan later changes as reviewed migrations. Access is restricted by the signed-in operator and row-level security.

## Data notes
129 customers were copied into the client database. At the time temporary map positions were added, 4 customers had saved coordinates and 125 lacked coordinates. Those 125 were assigned synthetic coordinates for map presentation at the user's request, marked internally with coordinateSource: "demo". They are not actual customer addresses. Existing saved coordinates were preserved. Replace synthetic positions with verified coordinates before relying on the map for visits. User-visible demo-location labels were subsequently removed at the user's request.

No customer exports, session tokens, passwords, secret keys or local authentication files are included in this package. Obtain database backups through the client's Supabase account. Share login credentials separately through the client's approved secure channel.
