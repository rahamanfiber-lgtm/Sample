begin;
insert into auth.users(id,email) values ('2dd846cc-5fea-4443-b1cc-64773e24bb34','fiberdesk-test-rollback@example.invalid');
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"2dd846cc-5fea-4443-b1cc-64773e24bb34","role":"authenticated","email":"rahaman.fiber@gmail.com"}',true);
do $test$
declare r bigint; snapshot jsonb;
begin
  r:=public.fiberdesk_save_workspace(0,$fixture$[{"id": "qa-transaction-only", "name": "Database test customer", "mobile": "0000000099", "alternate": "", "location": "Test only", "connection": "JioFiber", "plan": "Unlimited 30 Mbps", "amount": 599, "rechargeDate": "2026-11-20", "validity": 30, "expiryDate": "2026-12-20", "notes": "Rolled back test fixture", "demo": true, "renewals": [], "reminders": []}]$fixture$::jsonb);
  if r<>1 then raise exception 'Revision did not advance';end if;
  snapshot:=public.fiberdesk_load_workspace();
  if jsonb_array_length(snapshot->'customers')<>1 then raise exception 'Customer was not saved';end if;
  begin
    perform public.fiberdesk_save_workspace(0,'[]'::jsonb);
    raise exception 'Stale write was accepted';
  exception when serialization_failure then null;end;
  perform set_config('request.jwt.claims','{"sub":"2dd846cc-5fea-4443-b1cc-64773e24bb34","role":"authenticated","email":"not-the-operator@example.invalid"}',true);
  if (select count(*) from public.fiberdesk_customers)<>0 then raise exception 'RLS leaked rows';end if;
  begin
    perform public.fiberdesk_load_workspace();
    raise exception 'Unauthorized operator was accepted';
  exception when insufficient_privilege then null;end;
end $test$;
reset role;
do $test$
begin
 if has_table_privilege('anon','public.fiberdesk_customers','select') then raise exception 'Anonymous table access is enabled';end if;
 if has_function_privilege('anon','public.fiberdesk_load_workspace()','execute') then raise exception 'Anonymous RPC access is enabled';end if;
end $test$;
rollback;
select 'PASS: save/load, stale-write protection, owner-only RLS and anonymous denial. All test data rolled back.' as result;
