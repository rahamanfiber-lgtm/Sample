-- FiberDesk: one customer document per row, with typed indexed contact/expiry fields.
-- All application operations run as the signed-in user, never as a service role.
begin;
create table public.fiberdesk_workspaces (
  owner_id uuid primary key references auth.users(id) on delete cascade,
  revision bigint not null default 0 check (revision >= 0),
  updated_at timestamptz not null default now()
);
create table public.fiberdesk_customers (
  owner_id uuid not null references public.fiberdesk_workspaces(owner_id) on delete cascade,
  id text not null check (length(id) between 1 and 100),
  mobile text not null check (mobile ~ '^[0-9]{10}$'),
  expiry_date date not null,
  payload jsonb not null check (jsonb_typeof(payload) = 'object' and payload->>'id'=id and payload->>'mobile'=mobile),
  updated_at timestamptz not null default now(),
  primary key (owner_id, id),
  unique (owner_id, mobile)
);
create index fiberdesk_customers_expiry_idx on public.fiberdesk_customers(owner_id, expiry_date);
alter table public.fiberdesk_workspaces enable row level security;
alter table public.fiberdesk_customers enable row level security;
revoke all on public.fiberdesk_workspaces, public.fiberdesk_customers from anon, public;
grant select, insert, update, delete on public.fiberdesk_workspaces, public.fiberdesk_customers to authenticated;
create policy fiberdesk_workspace_owner on public.fiberdesk_workspaces for all to authenticated
using ((select auth.uid())=owner_id and lower((select auth.jwt())->>'email')='rahaman.fiber@gmail.com')
with check ((select auth.uid())=owner_id and lower((select auth.jwt())->>'email')='rahaman.fiber@gmail.com');
create policy fiberdesk_customer_owner on public.fiberdesk_customers for all to authenticated
using ((select auth.uid())=owner_id and lower((select auth.jwt())->>'email')='rahaman.fiber@gmail.com')
with check ((select auth.uid())=owner_id and lower((select auth.jwt())->>'email')='rahaman.fiber@gmail.com');

create function public.fiberdesk_load_workspace() returns jsonb
language plpgsql security invoker set search_path = '' as $$
declare result jsonb;
begin
  if auth.uid() is null or lower(coalesce(auth.jwt()->>'email','')) <> 'rahaman.fiber@gmail.com' then
    raise exception 'Only the FiberDesk operator can access this workspace' using errcode='42501';
  end if;
  select jsonb_build_object('initialized', true, 'revision', w.revision,
    'customers',coalesce((select jsonb_agg(c.payload order by c.expiry_date,c.id) from public.fiberdesk_customers c where c.owner_id=w.owner_id),'[]'::jsonb))
    into result from public.fiberdesk_workspaces w where w.owner_id=auth.uid();
  return coalesce(result,jsonb_build_object('initialized',false,'revision',0,'customers','[]'::jsonb));
end $$;

create function public.fiberdesk_save_workspace(expected_revision bigint, customers jsonb) returns bigint
language plpgsql security invoker set search_path = '' as $$
declare current_revision bigint; next_revision bigint; operator_id uuid:=auth.uid(); item jsonb;
begin
  if operator_id is null or lower(coalesce(auth.jwt()->>'email','')) <> 'rahaman.fiber@gmail.com' then
    raise exception 'Only the FiberDesk operator can save this workspace' using errcode='42501';
  end if;
  if jsonb_typeof(customers) is distinct from 'array' or jsonb_array_length(customers)>10000 then
    raise exception 'Invalid customer list' using errcode='22023';
  end if;
  insert into public.fiberdesk_workspaces(owner_id) values (operator_id) on conflict do nothing;
  select revision into current_revision from public.fiberdesk_workspaces where owner_id=operator_id for update;
  if expected_revision is null or current_revision<>expected_revision then
    raise exception 'Another device changed this workspace. Refresh before saving.' using errcode='40001';
  end if;
  if (select count(*)<>count(distinct value->>'id') from jsonb_array_elements(customers)) then
    raise exception 'Duplicate customer IDs' using errcode='22023';
  end if;
  -- Validate all rows before changing any record. The transaction is atomic.
  for item in select value from jsonb_array_elements(customers) loop
    if jsonb_typeof(item) is distinct from 'object'
      or nullif(btrim(item->>'name'),'') is null
      or (item->>'mobile') is null or (item->>'mobile') !~ '^[0-9]{10}$'
      or jsonb_typeof(item->'alternate') is distinct from 'string'
      or jsonb_typeof(item->'location') is distinct from 'string'
      or jsonb_typeof(item->'plan') is distinct from 'string'
      or jsonb_typeof(item->'notes') is distinct from 'string'
      or jsonb_typeof(item->'amount') is distinct from 'number'
      or (item->>'amount')::numeric < 0
      or nullif(item->>'rechargeDate','') is null
      or nullif(item->>'expiryDate','') is null
      or coalesce(item->>'connection','') not in ('JioFiber','Jio AirFiber')
      or coalesce(item->>'validity','') !~ '^[0-9]+$'
      or (item->>'validity')::integer not between 1 and 3650
      or jsonb_typeof(item->'reminders') is distinct from 'array'
      or jsonb_typeof(item->'renewals') is distinct from 'array'
      or jsonb_typeof(item->'demo') is distinct from 'boolean' then
      raise exception 'Invalid customer record' using errcode='22023';
    end if;
    if not (item->>'demo')::boolean and (item->>'mobile') !~ '^[6-9][0-9]{9}$' then
      raise exception 'Invalid Indian mobile number' using errcode='22023';
    end if;
    if (item->>'expiryDate')::date <> (item->>'rechargeDate')::date + (item->>'validity')::integer then
      raise exception 'Expiry does not match activation and validity' using errcode='22023';
    end if;
  end loop;
  -- Delete only records absent from this version; other users are always excluded.
  delete from public.fiberdesk_customers c where c.owner_id=operator_id and not exists
    (select 1 from jsonb_array_elements(customers) x where x->>'id'=c.id);
  -- Existing IDs are updated in place; conflicting mobiles fail the entire transaction.
  for item in select value from jsonb_array_elements(customers) loop
    insert into public.fiberdesk_customers(owner_id,id,mobile,expiry_date,payload)
    values(operator_id,item->>'id',item->>'mobile',(item->>'expiryDate')::date,item)
    on conflict(owner_id,id) do update set mobile=excluded.mobile,expiry_date=excluded.expiry_date,payload=excluded.payload,updated_at=now();
  end loop;
  update public.fiberdesk_workspaces set revision=revision+1,updated_at=now() where owner_id=operator_id returning revision into next_revision;
  return next_revision;
end $$;
revoke all on function public.fiberdesk_load_workspace() from public,anon;
revoke all on function public.fiberdesk_save_workspace(bigint,jsonb) from public,anon;
grant execute on function public.fiberdesk_load_workspace() to authenticated;
grant execute on function public.fiberdesk_save_workspace(bigint,jsonb) to authenticated;
-- This provider-created admin event trigger is never a client API.
-- Revoking client execution preserves the trigger and its owner privileges.
do $hardening$ begin
  if to_regprocedure('public.rls_auto_enable()') is not null then
    execute 'revoke execute on function public.rls_auto_enable() from public, anon, authenticated';
  end if;
end $hardening$;
commit;
